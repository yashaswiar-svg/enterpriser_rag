# Enterprise RAG Project Report

## 1. System Overview
The Enterprise RAG system is a research assistant built around a hybrid retrieval architecture and a robust document ingestion pipeline. It accepts user queries, applies input guardrails, performs both vector and BM25 retrieval, reranks results with FlashRank, compresses context, reasons with a ReAct agent over an LLM failover chain, validates output with output guardrails, and generates a polished PDF research report.

## 2. Embedding Model & Chunking Strategy
Embeddings are managed by `app.embeddings.embedding_manager.EmbeddingManager`. The system attempts to use Google Gemini embeddings first and falls back to `SentenceTransformerEmbeddings` with the model `all-MiniLM-L6-v2` if Gemini is unavailable.

Documents are chunked by `app.rag.document_processor.DocumentProcessor` using `langchain.text_splitter.RecursiveCharacterTextSplitter`. The chunker uses `CHUNK_SIZE=1000` and `CHUNK_OVERLAP=200`, ensuring dense coverage and manageable chunk sizes. Each chunk is stored with metadata including `document_id`, `document_name`, `page_number`, and `chunk_index`.

## 3. Vector Database & CRUD Operations
The persistent vector store is implemented in `app.vectorstore.chroma_store.ChromaVectorStore` using ChromaDB. It provides:
- `add_documents(...)` for upserts
- `query(...)` for embedding search
- `delete_documents(ids)` for chunk deletes
- `delete_by_document_id(document_id)` for full document removal
- `get_document_ids()` for verifying indexed documents

The ingestion pipeline stores document records and chunk metadata in SQLAlchemy models under `app.utils.database`, and it keeps the embedded chunk collection aligned with the SQL DB.

## 4. Retrieval Pipeline (BM25 + ChromaDB + RRF + FlashRank)
Retrieval is handled by `app.retrieval.hybrid_retriever.HybridRetriever`.

- Dense search uses ChromaDB vector similarity via `ChromaVectorStore.query()`.
- Sparse search uses a local BM25 index built from the ChromaDB contents in `BM25Retriever`.
- Reciprocal Rank Fusion (RRF) merges dense and sparse ranked lists into a single hybrid ranking.
- The top fused results are then reranked by `app.reranker.flashrank_reranker.FlashRankReranker`, producing a top-5 prioritized list for the LLM.

## 5. ReAct Reasoning Agent
The ReAct agent resides in `app.llm.react_agent.ReActAgent`. It formats a reasoning prompt with `REACT_STEP_PROMPT`, sends it through the LLM manager, and parses the output into Thought/Action/Observation steps. The agent returns a structured `ReActResult` containing the final answer, provider, model, and step count.

## 6. Prompt Engineering & Token Optimization
The system uses strict prompt templates in `app.llm.prompts`. The core system and ReAct prompts enforce:
- no hallucinations
- source citations for every claim
- rejection of injection or override attempts
- professional report formatting

Context is optimized in `app.retrieval.context_compressor.ContextCompressor` by deduplicating chunks, cleaning text, and trimming to a token budget (`MAX_CONTEXT_TOKENS=100000`). This reduces LLM cost and latency while preserving key evidence.

## 7. Security & Guardrails
Input guardrails are implemented in `app.guardrails.input_guard.py`. The guardrail detects prompt injection, jailbreak, role override, and other malicious patterns, returning a `GuardResult` with `threat_type` on violation.

Output guardrails are implemented in `app.guardrails.output_guard.py`. They validate LLM output against retrieved context, compute a confidence score, extract citations, and annotate warnings for low-confidence or hallucination-prone content.

## 8. API Failover & Resiliency
LLM failover is managed by `app.llm.llm_manager.LLMManager`. The chain is:
1. Gemini (primary)
2. OpenAI (fallback)
3. Raw retrieved chunk output if both providers fail

Embedding fallback is similarly resilient: Gemini embeddings are tried first, then SentenceTransformers if needed. This ensures the system can still return useful evidence even when API credentials are invalid.

## 9. Token & Latency Optimization
The system optimizes performance through:
- chunk compression and deduplication in `ContextCompressor`
- batching of embeddings in `IngestionPipeline._embed_and_index_chunks` using `BATCH_SIZE=50`
- retrieval fusion that limits top-K candidates and reranks only the best matches
- PDF generation using a lightweight report template in `app.reports.pdf_generator`

## 10. Open Source Libraries Used
- `pypdf` for PDF text extraction
- `reportlab` for PDF report generation
- `chromadb` for persistent vector storage
- `langchain` for text splitting
- `sentence_transformers` for fallback embeddings
- `flashrank` for reranking
- `requests` for HTTP downloads
- `sqlalchemy` for database models and sessions
- `pydantic-settings` for configuration
- `diagrams` for architecture diagram generation
- `openai` and Gemini client wrappers for LLM failover
