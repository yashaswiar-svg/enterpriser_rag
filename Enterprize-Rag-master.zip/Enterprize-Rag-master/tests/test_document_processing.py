"""
Tests for document processing and chunking.
"""
import pytest
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


from app.rag.document_processor import DocumentProcessor, DocumentChunk


class TestDocumentChunk:
    def test_chunk_creation(self):
        chunk = DocumentChunk(
            chunk_id="doc1_p1_c0",
            document_id="doc1",
            document_name="test.pdf",
            page_number=1,
            chunk_index=0,
            content="This is test content for the chunk.",
        )
        assert chunk.chunk_id == "doc1_p1_c0"
        assert chunk.document_id == "doc1"
        assert chunk.page_number == 1
        assert chunk.content_hash is not None
        assert chunk.token_count > 0

    def test_chunk_to_dict(self):
        chunk = DocumentChunk(
            chunk_id="test_chunk",
            document_id="doc1",
            document_name="test.pdf",
            page_number=2,
            chunk_index=1,
            content="Sample text content.",
        )
        d = chunk.to_dict()
        assert "chunk_id" in d
        assert "document_id" in d
        assert "page_number" in d
        assert "content" in d
        assert d["page_number"] == 2

    def test_chunk_content_hash_consistency(self):
        content = "Consistent content"
        chunk1 = DocumentChunk("id1", "doc1", "test.pdf", 1, 0, content)
        chunk2 = DocumentChunk("id2", "doc1", "test.pdf", 1, 1, content)
        assert chunk1.content_hash == chunk2.content_hash


class TestDocumentProcessor:
    def setup_method(self):
        self.processor = DocumentProcessor()

    def test_txt_file_processing(self):
        """Test processing a simple text file."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as f:
            f.write("This is a test document.\n\n" * 100)
            temp_path = f.name

        try:
            doc_id, chunks = self.processor.process_document(temp_path, "test_doc_1", "test.txt")
            assert doc_id == "test_doc_1"
            assert len(chunks) > 0
            assert all(isinstance(c, DocumentChunk) for c in chunks)
            assert all(c.document_id == "test_doc_1" for c in chunks)
        finally:
            os.unlink(temp_path)

    def test_chunk_metadata(self):
        """Test that chunks have proper metadata."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as f:
            f.write("Enterprise AI research findings. " * 200)
            temp_path = f.name

        try:
            _, chunks = self.processor.process_document(temp_path, "meta_test", "meta.txt")
            for chunk in chunks:
                assert chunk.document_name == "meta.txt"
                assert chunk.page_number >= 1
                assert chunk.chunk_index >= 0
                assert "document_id" in chunk.metadata
                assert "page_number" in chunk.metadata
        finally:
            os.unlink(temp_path)

    def test_large_document_chunking(self):
        """Test that large documents are properly chunked."""
        large_content = "This is a detailed technical document. " * 5000
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as f:
            f.write(large_content)
            temp_path = f.name

        try:
            _, chunks = self.processor.process_document(temp_path, "large_doc", "large.txt")
            assert len(chunks) > 10  # Should create many chunks
            # All chunks should be within size limits
            for chunk in chunks:
                assert len(chunk.content) <= 1500  # Some tolerance for overlap
        finally:
            os.unlink(temp_path)

    def test_chunk_ids_are_unique(self):
        """Test that all chunk IDs are unique."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as f:
            f.write("Unique content for testing. " * 500)
            temp_path = f.name

        try:
            _, chunks = self.processor.process_document(temp_path, "unique_test", "unique.txt")
            chunk_ids = [c.chunk_id for c in chunks]
            assert len(chunk_ids) == len(set(chunk_ids)), "Duplicate chunk IDs found"
        finally:
            os.unlink(temp_path)

    def test_empty_file_handling(self):
        """Test handling of an empty file."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as f:
            f.write("")
            temp_path = f.name

        try:
            _, chunks = self.processor.process_document(temp_path, "empty_doc", "empty.txt")
            assert len(chunks) == 0
        finally:
            os.unlink(temp_path)

    def test_process_specific_pages(self):
        """Test re-processing specific pages only."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as f:
            f.write("Page 1 content here. " * 100)
            temp_path = f.name

        try:
            chunks = self.processor.process_document_pages(
                temp_path, "page_test", "page.txt", [1]
            )
            assert all(c.page_number == 1 for c in chunks)
        finally:
            os.unlink(temp_path)
