"""
Test configuration and shared fixtures.
"""
import os
import sys
import pytest
import tempfile

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Use in-memory SQLite for tests
os.environ["DATABASE_URL"] = "sqlite:///:memory:"
os.environ["CHROMA_PERSIST_DIR"] = tempfile.mkdtemp()
os.environ["REPORTS_DIR"] = tempfile.mkdtemp()
os.environ["LOGS_DIR"] = tempfile.mkdtemp()
os.environ["DOCUMENTS_DIR"] = tempfile.mkdtemp()


@pytest.fixture(autouse=True)
def init_test_db():
    """Initialize in-memory database for each test."""
    from app.utils.database import init_db
    init_db()


@pytest.fixture
def sample_chunks():
    """Sample document chunks for testing."""
    return [
        {
            "id": f"chunk_{i}",
            "content": f"This is test chunk {i} containing relevant research information about AI and machine learning.",
            "score": 0.9 - i * 0.05,
            "metadata": {
                "document_id": "doc_1",
                "document_name": "research_paper.pdf",
                "page_number": i + 1,
                "chunk_index": i,
            },
        }
        for i in range(10)
    ]


@pytest.fixture
def sample_query():
    return "What are the key findings from the AI research documents?"


@pytest.fixture
def sample_document_content():
    return """
    Executive Summary
    
    This research paper investigates the application of machine learning algorithms
    in enterprise environments. Key findings indicate significant improvements in
    processing efficiency and accuracy.
    
    Chapter 1: Introduction
    
    Machine learning has revolutionized data analysis across industries.
    Companies implementing AI solutions report 40% improvement in operational efficiency.
    
    Chapter 2: Methodology
    
    The study analyzed 500 enterprise deployments across 50 different industries.
    Data collection spanned 24 months with quarterly assessments.
    
    Chapter 3: Results
    
    Results demonstrate that supervised learning algorithms outperform rule-based systems
    by a factor of 3.2x in classification tasks. Neural networks achieve 95% accuracy
    on complex pattern recognition problems.
    
    Chapter 4: Conclusions
    
    Enterprise AI adoption requires careful planning, robust infrastructure, and
    continuous monitoring. Organizations should prioritize data quality and model
    interpretability for sustainable deployment.
    """
