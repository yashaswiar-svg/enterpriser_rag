"""
Integration tests for document CRUD operations.
"""
import pytest
import os
import sys
import tempfile
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestDocumentCRUD:
    """Test complete CRUD operations for documents."""

    def test_document_metadata_schema(self):
        """Test document metadata has required fields."""
        from app.utils.database import Document
        from datetime import datetime

        doc = Document(
            document_id="test-doc-001",
            document_name="test_document.pdf",
            total_pages=10,
            total_chunks=50,
            status="indexed",
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
        )

        assert doc.document_id == "test-doc-001"
        assert doc.document_name == "test_document.pdf"
        assert doc.total_pages == 10
        assert doc.total_chunks == 50
        assert doc.status == "indexed"
        assert doc.created_at is not None
        assert doc.updated_at is not None

    def test_chunk_metadata_schema(self):
        """Test chunk metadata has required fields."""
        from app.utils.database import Chunk
        from datetime import datetime

        chunk = Chunk(
            chunk_id="test-doc-001_p1_c0",
            document_id="test-doc-001",
            document_name="test.pdf",
            page_number=1,
            chunk_index=0,
            content="Test chunk content",
            is_indexed=True,
        )

        assert chunk.chunk_id == "test-doc-001_p1_c0"
        assert chunk.document_id == "test-doc-001"
        assert chunk.page_number == 1
        assert chunk.chunk_index == 0
        assert chunk.is_indexed is True

    def test_database_initialization(self):
        """Test database can be initialized."""
        from app.utils.database import init_db, Base
        # Should not raise
        init_db()

    def test_db_session_context(self):
        """Test database session yields correctly."""
        from app.utils.database import get_db, init_db
        init_db()
        db_gen = get_db()
        db = next(db_gen)
        assert db is not None
        try:
            next(db_gen)
        except StopIteration:
            pass  # Expected

    def test_document_status_transitions(self):
        """Test document status can be updated."""
        statuses = ["pending", "processing", "indexed", "failed"]
        from app.utils.database import Document

        for status in statuses:
            doc = Document(
                document_id=f"doc_{status}",
                document_name="test.pdf",
                status=status,
            )
            assert doc.status == status


class TestCacheOperations:
    def test_lru_cache_set_get(self):
        from app.utils.cache import LRUCache
        cache = LRUCache(max_size=10, ttl=3600)
        cache.set("key1", "value1")
        assert cache.get("key1") == "value1"

    def test_lru_cache_miss(self):
        from app.utils.cache import LRUCache
        cache = LRUCache(max_size=10, ttl=3600)
        assert cache.get("nonexistent") is None

    def test_lru_cache_eviction(self):
        from app.utils.cache import LRUCache
        cache = LRUCache(max_size=3, ttl=3600)
        cache.set("a", 1)
        cache.set("b", 2)
        cache.set("c", 3)
        cache.set("d", 4)  # Should evict "a"
        assert cache.get("a") is None
        assert cache.get("d") == 4

    def test_lru_cache_delete(self):
        from app.utils.cache import LRUCache
        cache = LRUCache(max_size=10, ttl=3600)
        cache.set("key1", "value1")
        deleted = cache.delete("key1")
        assert deleted is True
        assert cache.get("key1") is None

    def test_cache_stats(self):
        from app.utils.cache import LRUCache
        cache = LRUCache(max_size=10, ttl=3600)
        cache.set("k1", "v1")
        cache.get("k1")  # hit
        cache.get("k2")  # miss
        stats = cache.stats()
        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["hit_rate"] == 0.5

    def test_embedding_cache(self):
        from app.utils.cache import EmbeddingCache
        cache = EmbeddingCache()
        embedding = [0.1, 0.2, 0.3, 0.4, 0.5]
        cache.set_embedding("test text", "test-model", embedding)
        result = cache.get_embedding("test text", "test-model")
        assert result == embedding

    def test_chunk_cache(self):
        from app.utils.cache import ChunkCache
        cache = ChunkCache()
        chunks = [{"id": "chunk1", "content": "test"}]
        cache.set_chunks("test query", 5, chunks)
        result = cache.get_chunks("test query", 5)
        assert result == chunks

    def test_lru_cache_clear(self):
        from app.utils.cache import LRUCache
        cache = LRUCache(max_size=10, ttl=3600)
        cache.set("k1", "v1")
        cache.set("k2", "v2")
        cache.clear()
        assert cache.get("k1") is None
        assert cache.get("k2") is None
