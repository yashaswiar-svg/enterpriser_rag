"""
Tests for FlashRank reranker.
"""
import pytest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.reranker.flashrank_reranker import FlashRankReranker


class TestFlashRankReranker:
    def setup_method(self):
        self.reranker = FlashRankReranker(top_n=5)

    def _make_chunks(self, n: int = 10):
        return [
            {
                "id": f"chunk_{i}",
                "content": f"This is chunk {i} about machine learning and AI research.",
                "score": 0.9 - i * 0.05,
                "metadata": {
                    "document_name": f"doc_{i}.pdf",
                    "page_number": i + 1,
                    "document_id": f"doc_{i}",
                },
            }
            for i in range(n)
        ]

    def test_rerank_returns_top_n(self):
        chunks = self._make_chunks(15)
        result = self.reranker.rerank("machine learning research", chunks, top_n=5)
        assert len(result) == 5

    def test_rerank_fewer_than_top_n(self):
        chunks = self._make_chunks(3)
        result = self.reranker.rerank("machine learning", chunks, top_n=5)
        assert len(result) == 3

    def test_rerank_empty_input(self):
        result = self.reranker.rerank("query", [], top_n=5)
        assert result == []

    def test_rerank_preserves_content(self):
        chunks = self._make_chunks(8)
        result = self.reranker.rerank("AI research findings", chunks)
        # All returned chunks should have content
        for chunk in result:
            assert "content" in chunk
            assert len(chunk["content"]) > 0

    def test_rerank_with_scores(self):
        chunks = self._make_chunks(10)
        result = self.reranker.rerank_with_scores("machine learning accuracy", chunks)
        for chunk in result:
            assert "confidence" in chunk
            assert 0.0 <= chunk["confidence"] <= 1.0

    def test_score_based_fallback(self):
        chunks = self._make_chunks(10)
        result = self.reranker._score_based_rerank("test query", chunks, top_n=5)
        assert len(result) == 5
        # Should be sorted by score descending
        scores = [max(c.get("score", 0), c.get("hybrid_score", 0)) for c in result]
        assert scores == sorted(scores, reverse=True)

    def test_rerank_single_chunk(self):
        chunks = self._make_chunks(1)
        result = self.reranker.rerank("query", chunks, top_n=5)
        assert len(result) == 1

    def test_default_top_n(self):
        from app.config.settings import settings
        chunks = self._make_chunks(20)
        result = self.reranker.rerank("query", chunks)
        assert len(result) == settings.RERANK_TOP_N
