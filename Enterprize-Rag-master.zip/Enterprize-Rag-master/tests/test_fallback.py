"""
Tests for LLM fallback chain and API failover.
"""
import pytest
import sys
import os
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestLLMFallback:
    def test_raw_chunks_fallback_format(self):
        """Test that raw chunks fallback returns formatted response."""
        from app.llm.llm_manager import LLMManager
        mgr = LLMManager.__new__(LLMManager)
        mgr._gemini = None
        mgr._openai = None

        chunks = [
            {
                "id": "c1",
                "content": "Machine learning model performance analysis",
                "metadata": {"document_name": "research.pdf", "page_number": 3},
            }
        ]
        raw = mgr._format_raw_chunks(chunks)
        assert "AI Generation Unavailable" in raw
        assert "research.pdf" in raw
        assert "Machine learning" in raw

    def test_raw_chunks_no_chunks(self):
        """Test fallback with empty chunks list."""
        from app.llm.llm_manager import LLMManager
        mgr = LLMManager.__new__(LLMManager)
        mgr._gemini = None
        mgr._openai = None

        raw = mgr._format_raw_chunks([])
        assert "AI Generation Unavailable" in raw
        assert "API keys" in raw

    def test_llm_result_structure(self):
        """Test LLMResult has expected attributes."""
        from app.llm.llm_manager import LLMResult
        result = LLMResult(
            content="Test response",
            provider="gemini",
            model="gemini-2.5-flash",
            latency_ms=150.5,
            is_fallback=False,
            is_raw=False,
        )
        assert result.content == "Test response"
        assert result.provider == "gemini"
        assert result.latency_ms == 150.5
        assert result.is_fallback is False

    def test_fallback_result_marked(self):
        """Test fallback result is properly marked."""
        from app.llm.llm_manager import LLMResult
        result = LLMResult(
            content="Fallback response",
            provider="openai",
            model="gpt-4o",
            latency_ms=300.0,
            is_fallback=True,
        )
        assert result.is_fallback is True

    def test_active_provider_none(self):
        """Test active_provider when no providers available."""
        from app.llm.llm_manager import LLMManager
        mgr = LLMManager.__new__(LLMManager)
        mgr._gemini = None
        mgr._openai = None
        assert mgr.active_provider == "none"

    def test_active_provider_gemini(self):
        """Test active_provider when Gemini available."""
        from app.llm.llm_manager import LLMManager
        mgr = LLMManager.__new__(LLMManager)
        mgr._gemini = MagicMock()
        mgr._openai = None
        assert mgr.active_provider == "gemini"

    def test_active_provider_openai_fallback(self):
        """Test active_provider when only OpenAI available."""
        from app.llm.llm_manager import LLMManager
        mgr = LLMManager.__new__(LLMManager)
        mgr._gemini = None
        mgr._openai = MagicMock()
        assert mgr.active_provider == "openai"


class TestContextCompressor:
    def test_compress_empty(self):
        from app.retrieval.context_compressor import ContextCompressor
        comp = ContextCompressor()
        result = comp.compress([])
        assert result == []

    def test_compress_removes_duplicates(self):
        from app.retrieval.context_compressor import ContextCompressor
        comp = ContextCompressor()
        chunks = [
            {"id": "c1", "content": "Same content here exactly", "score": 0.9},
            {"id": "c2", "content": "Same content here exactly", "score": 0.8},
        ]
        result = comp.compress(chunks)
        assert len(result) == 1

    def test_compress_token_limit(self):
        from app.retrieval.context_compressor import ContextCompressor
        comp = ContextCompressor(max_tokens=100)
        chunks = [
            {"id": f"c{i}", "content": "word " * 200, "score": 0.9 - i * 0.1}
            for i in range(10)
        ]
        result = comp.compress(chunks)
        assert len(result) < 10

    def test_format_context(self):
        from app.retrieval.context_compressor import ContextCompressor
        comp = ContextCompressor()
        chunks = [
            {
                "id": "c1",
                "content": "Important finding about AI",
                "metadata": {"document_name": "research.pdf", "page_number": 5},
            }
        ]
        formatted = comp.format_context(chunks)
        assert "[Source 1]" in formatted
        assert "research.pdf" in formatted
        assert "Page: 5" in formatted
        assert "Important finding about AI" in formatted

    def test_format_empty_context(self):
        from app.retrieval.context_compressor import ContextCompressor
        comp = ContextCompressor()
        result = comp.format_context([])
        assert "No relevant context" in result

    def test_compress_sorts_by_score(self):
        from app.retrieval.context_compressor import ContextCompressor
        comp = ContextCompressor()
        chunks = [
            {"id": "low", "content": "Low relevance content chunk", "score": 0.2},
            {"id": "high", "content": "High relevance content chunk", "score": 0.9},
            {"id": "med", "content": "Medium relevance content text", "score": 0.6},
        ]
        result = comp.compress(chunks)
        scores = [c.get("score", 0) for c in result]
        assert scores == sorted(scores, reverse=True)


class TestReActParsing:
    def test_parse_react_output_with_final_answer(self):
        from app.llm.react_agent import ReActAgent
        agent = ReActAgent.__new__(ReActAgent)

        output = """
Thought 1: I need to analyze the documents.
Action 1: Search vector database for relevant chunks.
Observation 1: Found 5 relevant chunks about machine learning.

Thought 2: I have enough evidence to answer.
Action 2: Synthesize findings.
Observation 2: Key findings identified.

Final Answer: Based on the retrieved context, machine learning achieves 95% accuracy.
"""
        steps, final = agent._parse_react_output(output)
        assert len(steps) > 0
        assert "machine learning" in final.lower()

    def test_parse_react_no_final_answer(self):
        from app.llm.react_agent import ReActAgent
        agent = ReActAgent.__new__(ReActAgent)

        output = "This is the complete response without explicit final answer marker."
        steps, final = agent._parse_react_output(output)
        assert final == output.strip()
