"""
Document CRUD API endpoints.
Supports add, update pages, delete, delete pages, re-index.
"""
import os
from typing import List, Optional
from datetime import datetime

from fastapi import APIRouter, UploadFile, File, HTTPException, Depends, BackgroundTasks, Query
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.api.models import (
    DocumentUploadResponse, DocumentMetadata, DocumentListResponse,
    DocumentDeleteResponse, PageDeleteRequest, PageUpdateRequest
)
from app.rag.ingestion_pipeline import ingestion_pipeline
from app.utils.database import get_db, Document, Chunk
from app.config.settings import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/documents", tags=["Documents"])

ALLOWED_EXTENSIONS = {".pdf", ".txt", ".md", ".docx"}
MAX_FILE_SIZE = settings.MAX_FILE_SIZE_MB * 1024 * 1024


def _validate_file(file: UploadFile):
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{ext}'. Allowed: {ALLOWED_EXTENSIONS}"
        )


@router.post("/upload", response_model=DocumentUploadResponse, status_code=201)
async def upload_document(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """
    Upload and index a new document.
    Supports PDF, TXT, DOCX, MD.
    """
    _validate_file(file)

    content = await file.read()
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=413,
            detail=f"File too large. Max size: {settings.MAX_FILE_SIZE_MB}MB"
        )

    try:
        result = await ingestion_pipeline.aingest_document(
            file_content=content,
            filename=file.filename,
        )
        return DocumentUploadResponse(
            document_id=result["document_id"],
            document_name=result["document_name"],
            total_pages=result["total_pages"],
            total_chunks=result["total_chunks"],
            indexed=result["indexed"],
            status=result["status"],
        )
    except Exception as e:
        logger.error(f"Upload failed: {e}")
        raise HTTPException(status_code=500, detail=f"Document processing failed: {str(e)}")


@router.get("/", response_model=DocumentListResponse)
def list_documents(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=500),
    status: Optional[str] = Query(None),
    db: Session = Depends(get_db),
):
    """List all documents with pagination."""
    query = db.query(Document)
    if status:
        query = query.filter(Document.status == status)
    total = query.count()
    docs = query.offset(skip).limit(limit).all()

    return DocumentListResponse(
        documents=[
            DocumentMetadata(
                document_id=d.document_id,
                document_name=d.document_name,
                created_at=d.created_at.isoformat() if d.created_at else None,
                updated_at=d.updated_at.isoformat() if d.updated_at else None,
                total_pages=d.total_pages,
                total_chunks=d.total_chunks,
                file_size=d.file_size,
                status=d.status,
            )
            for d in docs
        ],
        total=total,
    )


@router.get("/{document_id}", response_model=DocumentMetadata)
def get_document(document_id: str, db: Session = Depends(get_db)):
    """Get document metadata by ID."""
    doc = db.query(Document).filter(Document.document_id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail=f"Document '{document_id}' not found")

    return DocumentMetadata(
        document_id=doc.document_id,
        document_name=doc.document_name,
        created_at=doc.created_at.isoformat() if doc.created_at else None,
        updated_at=doc.updated_at.isoformat() if doc.updated_at else None,
        total_pages=doc.total_pages,
        total_chunks=doc.total_chunks,
        file_size=doc.file_size,
        status=doc.status,
    )


@router.delete("/{document_id}", response_model=DocumentDeleteResponse)
def delete_document(document_id: str, db: Session = Depends(get_db)):
    """
    Delete a document and ALL its indexed chunks.
    Does NOT rebuild the entire database.
    """
    doc = db.query(Document).filter(Document.document_id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail=f"Document '{document_id}' not found")

    try:
        result = ingestion_pipeline.delete_document(document_id)
        return DocumentDeleteResponse(
            document_id=document_id,
            deleted_chunks=result["deleted_chunks"],
            status="deleted",
            message=f"Document and {result['deleted_chunks']} chunks deleted successfully",
        )
    except Exception as e:
        logger.error(f"Delete failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{document_id}/pages", response_model=dict)
def delete_document_pages(
    document_id: str,
    request: PageDeleteRequest,
    db: Session = Depends(get_db),
):
    """
    Delete specific pages from a document.
    Only removes those pages — never rebuilds entire index.
    """
    doc = db.query(Document).filter(Document.document_id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail=f"Document '{document_id}' not found")

    try:
        result = ingestion_pipeline.delete_document_pages(document_id, request.page_numbers)
        return {
            "document_id": document_id,
            "deleted_pages": result["deleted_pages"],
            "deleted_chunks": result["deleted_chunks"],
            "status": "pages_deleted",
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{document_id}/pages", response_model=dict)
def reindex_document_pages(
    document_id: str,
    request: PageUpdateRequest,
    db: Session = Depends(get_db),
):
    """
    Re-index specific pages only (incremental update).
    Does NOT rebuild entire document index.
    """
    doc = db.query(Document).filter(Document.document_id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail=f"Document '{document_id}' not found")

    try:
        result = ingestion_pipeline.update_document_pages(document_id, request.page_numbers)
        return {
            "document_id": document_id,
            "pages_updated": result["pages_updated"],
            "new_chunks": result["new_chunks"],
            "indexed": result["indexed"],
            "status": "pages_updated",
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{document_id}/chunks", response_model=dict)
def get_document_chunks(
    document_id: str,
    page: int = Query(None),
    db: Session = Depends(get_db),
):
    """Get chunks for a document, optionally filtered by page."""
    doc = db.query(Document).filter(Document.document_id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    q = db.query(Chunk).filter(Chunk.document_id == document_id)
    if page is not None:
        q = q.filter(Chunk.page_number == page)
    chunks = q.order_by(Chunk.page_number, Chunk.chunk_index).all()

    return {
        "document_id": document_id,
        "total_chunks": len(chunks),
        "chunks": [
            {
                "chunk_id": c.chunk_id,
                "page_number": c.page_number,
                "chunk_index": c.chunk_index,
                "content_preview": c.content[:200] + "..." if len(c.content) > 200 else c.content,
                "token_count": c.token_count,
                "is_indexed": c.is_indexed,
            }
            for c in chunks
        ],
    }
