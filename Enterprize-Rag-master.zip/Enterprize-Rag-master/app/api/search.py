"""
Search API endpoints for querying the knowledge base.
"""
from fastapi import APIRouter, HTTPException, Request

from app.api.models import SearchRequest, SearchResponse, SearchResultChunk
from app.retrieval.hybrid_retriever import hybrid_retriever
from app.reranker.flashrank_reranker import reranker
from app.guardrails.input_guard import input_guardrail
from app.utils.logger import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/search", tags=["Search"])


@router.post("/", response_model=SearchResponse)
async def search_knowledge_base(
    request_data: SearchRequest,
    request: Request,
):
    """
    Search the knowledge base using hybrid retrieval + reranking.
    Returns relevant document chunks.
    """
    source_ip = request.client.host if request.client else None

    # Input validation
    guard = input_guardrail.check(request_data.query, source_ip)
    if not guard.is_safe:
        raise HTTPException(status_code=400, detail=guard.message)

    try:
        # Retrieve
        chunks = hybrid_retriever.retrieve(
            query=request_data.query,
            top_k=request_data.top_k * 4,  # retrieve more for reranking
            document_ids=request_data.document_ids,
            use_hybrid=request_data.use_hybrid,
        )

        # Rerank
        if len(chunks) > request_data.top_k:
            chunks = reranker.rerank(
                query=request_data.query,
                chunks=chunks,
                top_n=request_data.top_k,
            )

        results = []
        for chunk in chunks[:request_data.top_k]:
            meta = chunk.get("metadata", {})
            results.append(SearchResultChunk(
                id=chunk.get("id", ""),
                content=chunk.get("content", ""),
                document_name=meta.get("document_name", "Unknown"),
                page_number=meta.get("page_number", "?"),
                score=float(chunk.get("score", chunk.get("hybrid_score", 0))),
                rerank_score=chunk.get("rerank_score"),
            ))

        return SearchResponse(
            query=request_data.query,
            results=results,
            total=len(results),
        )

    except Exception as e:
        logger.error(f"Search failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))
