"""
System monitoring and admin API endpoints.
"""
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.api.models import SystemStatsResponse
from app.vectorstore.chroma_store import ChromaVectorStore
from app.embeddings.embedding_manager import embedding_manager
from app.llm.llm_manager import llm_manager
from app.utils.database import get_db, Document, Report, AuditLog, SecurityEvent, Chunk
from app.utils.cache import embedding_cache, chunk_cache
from app.config.settings import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/system", tags=["System"])


@router.get("/stats", response_model=SystemStatsResponse)
def get_system_stats(db: Session = Depends(get_db)):
    """Get comprehensive system statistics."""
    vector_store = ChromaVectorStore()

    total_docs = db.query(Document).count()
    total_reports = db.query(Report).count()

    return SystemStatsResponse(
        total_documents=total_docs,
        total_chunks_indexed=vector_store.count(),
        total_reports=total_reports,
        vector_store_stats=vector_store.get_collection_stats(),
        embedding_cache_stats=embedding_cache.stats(),
        chunk_cache_stats=chunk_cache.stats(),
        active_llm_provider=llm_manager.active_provider,
        active_embedding_model=embedding_manager.model_name,
        system_status="healthy",
    )


@router.get("/health")
def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": settings.APP_VERSION,
        "environment": settings.ENVIRONMENT,
    }


@router.get("/audit-logs")
def get_audit_logs(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
    action: str = Query(None),
    db: Session = Depends(get_db),
):
    """Get audit log entries."""
    q = db.query(AuditLog)
    if action:
        q = q.filter(AuditLog.action == action)
    total = q.count()
    logs = q.order_by(AuditLog.created_at.desc()).offset(skip).limit(limit).all()

    return {
        "total": total,
        "logs": [
            {
                "id": log.id,
                "action": log.action,
                "entity_type": log.entity_type,
                "entity_id": log.entity_id,
                "details": log.details,
                "created_at": log.created_at.isoformat() if log.created_at else None,
            }
            for log in logs
        ],
    }


@router.get("/security-events")
def get_security_events(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
    severity: str = Query(None),
    db: Session = Depends(get_db),
):
    """Get security event logs."""
    q = db.query(SecurityEvent)
    if severity:
        q = q.filter(SecurityEvent.severity == severity)
    total = q.count()
    events = q.order_by(SecurityEvent.created_at.desc()).offset(skip).limit(limit).all()

    return {
        "total": total,
        "events": [
            {
                "id": ev.id,
                "event_type": ev.event_type,
                "severity": ev.severity,
                "source_ip": ev.source_ip,
                "details": ev.details,
                "resolved": ev.resolved,
                "created_at": ev.created_at.isoformat() if ev.created_at else None,
            }
            for ev in events
        ],
    }


@router.get("/analytics")
def get_analytics(
    days: int = Query(7, ge=1, le=90),
    db: Session = Depends(get_db),
):
    """Get usage analytics."""
    since = datetime.utcnow() - timedelta(days=days)

    total_reports = db.query(Report).filter(Report.created_at >= since).count()
    total_docs = db.query(Document).filter(Document.created_at >= since).count()
    security_events = db.query(SecurityEvent).filter(SecurityEvent.created_at >= since).count()

    # Average confidence score
    reports_with_score = db.query(Report).filter(
        Report.created_at >= since,
        Report.confidence_score.isnot(None)
    ).all()
    avg_confidence = (
        sum(r.confidence_score for r in reports_with_score) / len(reports_with_score)
        if reports_with_score else 0.0
    )

    # Provider breakdown
    provider_breakdown = {}
    for r in db.query(Report).filter(Report.created_at >= since).all():
        p = r.llm_provider or "unknown"
        provider_breakdown[p] = provider_breakdown.get(p, 0) + 1

    # Avg processing time
    times = [r.processing_time for r in reports_with_score if r.processing_time]
    avg_time = sum(times) / len(times) if times else 0.0

    return {
        "period_days": days,
        "total_reports_generated": total_reports,
        "total_documents_uploaded": total_docs,
        "security_events": security_events,
        "avg_confidence_score": round(avg_confidence, 3),
        "avg_processing_time_s": round(avg_time, 2),
        "provider_breakdown": provider_breakdown,
        "vector_store_total_chunks": ChromaVectorStore().count(),
    }


@router.post("/cache/clear")
def clear_cache():
    """Clear all caches."""
    from app.utils.cache import embedding_cache, chunk_cache, general_cache
    embedding_cache.clear()
    chunk_cache.clear()
    general_cache.clear()
    return {"status": "cleared", "message": "All caches cleared successfully"}
