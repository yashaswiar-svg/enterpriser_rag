from .documents import router as documents_router
from .reports import router as reports_router
from .search import router as search_router
from .system import router as system_router

__all__ = ["documents_router", "reports_router", "search_router", "system_router"]
