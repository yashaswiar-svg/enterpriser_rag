"""
Report generation and management API endpoints.
"""
import os
from typing import Optional
from datetime import datetime

from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks, Request, Query
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.api.models import (
    ReportRequest, ReportResponse, ReportListResponse, ReportListItem,
    FeedbackRequest, FeedbackResponse,
)
from app.reports.report_engine import report_engine
from app.utils.database import get_db, Report, FeedbackEntry
from app.config.settings import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/reports", tags=["Reports"])


@router.post("/generate", response_model=ReportResponse, status_code=201)
async def generate_report(
    request_data: ReportRequest,
    request: Request,
    db: Session = Depends(get_db),
):
    """
    Generate a structured research report with PDF export.
    
    Full pipeline:
    1. Input validation (guardrails)
    2. Hybrid retrieval (vector + BM25)  
    3. FlashRank reranking (top-20 → top-5)
    4. Context compression
    5. ReAct reasoning + LLM generation
    6. Output validation
    7. PDF generation
    """
    source_ip = request.client.host if request.client else None

    try:
        result = report_engine.generate_report(
            query=request_data.query,
            document_ids=request_data.document_ids,
            use_react=request_data.use_react,
            source_ip=source_ip,
        )

        # Security violation
        if result.get("status") == "security_violation":
            raise HTTPException(status_code=400, detail=result.get("message"))

        # Build PDF URL
        pdf_url = None
        if result.get("pdf_path"):
            pdf_filename = os.path.basename(result["pdf_path"])
            pdf_url = f"/reports/{result['report_id']}/download"

        return ReportResponse(
            report_id=result["report_id"],
            query=result["query"],
            title=result.get("title", ""),
            status=result.get("status", "completed"),
            confidence_score=result.get("confidence_score", 0.0),
            provider=result.get("provider", ""),
            model=result.get("model", ""),
            citations=result.get("citations", []),
            warnings=result.get("warnings", []),
            retrieved_chunks=result.get("retrieved_chunks", 0),
            reranked_chunks=result.get("reranked_chunks", 0),
            compressed_chunks=result.get("compressed_chunks", 0),
            react_steps=result.get("react_steps", 0),
            react_reasoning=result.get("react_reasoning", []),
            processing_time_s=result.get("processing_time_s", 0.0),
            pdf_url=pdf_url,
            content=result.get("content"),
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Report generation failed: {e}")
        raise HTTPException(status_code=500, detail=f"Report generation failed: {str(e)}")


@router.get("/", response_model=ReportListResponse)
def list_reports(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    """List all generated reports."""
    total = db.query(Report).count()
    reports = (
        db.query(Report)
        .order_by(Report.created_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )

    return ReportListResponse(
        reports=[
            ReportListItem(
                report_id=r.report_id,
                query=r.query,
                title=r.title,
                status=r.status,
                confidence_score=r.confidence_score or 0.0,
                llm_provider=r.llm_provider,
                processing_time=r.processing_time,
                created_at=r.created_at.isoformat() if r.created_at else None,
                pdf_url=f"/reports/{r.report_id}/download" if r.pdf_path else None,
            )
            for r in reports
        ],
        total=total,
    )


@router.get("/{report_id}", response_model=ReportResponse)
def get_report(report_id: str, db: Session = Depends(get_db)):
    """Get report metadata by ID."""
    report = db.query(Report).filter(Report.report_id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail=f"Report '{report_id}' not found")

    content = None
    if report.sections and isinstance(report.sections, dict):
        content = report.sections.get("content")

    return ReportResponse(
        report_id=report.report_id,
        query=report.query,
        title=report.title or "",
        status=report.status,
        confidence_score=report.confidence_score or 0.0,
        provider=report.llm_provider or "",
        citations=report.citations or [],
        processing_time_s=report.processing_time or 0.0,
        pdf_url=f"/reports/{report.report_id}/download" if report.pdf_path else None,
        content=content,
    )


@router.get("/{report_id}/download")
def download_report(report_id: str, db: Session = Depends(get_db)):
    """Download the PDF report."""
    report = db.query(Report).filter(Report.report_id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    if not report.pdf_path or not os.path.exists(report.pdf_path):
        raise HTTPException(status_code=404, detail="PDF file not found")

    return FileResponse(
        path=report.pdf_path,
        media_type="application/pdf",
        filename=f"report_{report_id}.pdf",
    )


@router.delete("/{report_id}", response_model=dict)
def delete_report(report_id: str, db: Session = Depends(get_db)):
    """Delete a report and its PDF."""
    report = db.query(Report).filter(Report.report_id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    # Delete PDF file
    if report.pdf_path and os.path.exists(report.pdf_path):
        try:
            os.remove(report.pdf_path)
        except Exception as e:
            logger.warning(f"Could not delete PDF file at {report.pdf_path}: {e}")

    db.delete(report)
    db.commit()

    return {"report_id": report_id, "status": "deleted"}


@router.post("/feedback", response_model=FeedbackResponse)
def submit_feedback(
    feedback: FeedbackRequest,
    db: Session = Depends(get_db),
):
    """Submit feedback for a report or query."""
    import uuid
    feedback_id = str(uuid.uuid4())
    entry = FeedbackEntry(
        id=feedback_id,
        report_id=feedback.report_id,
        query=feedback.query,
        rating=feedback.rating,
        comment=feedback.comment,
        helpful=feedback.helpful,
    )
    db.add(entry)
    db.commit()

    return FeedbackResponse(
        feedback_id=feedback_id,
        status="submitted",
        message="Feedback submitted successfully. Thank you!",
    )
