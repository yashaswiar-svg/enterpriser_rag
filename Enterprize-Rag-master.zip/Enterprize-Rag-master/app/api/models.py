"""
Pydantic request/response models for the API.
"""
from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field


# ── Document Models ────────────────────────────────────────────────────────────

class DocumentUploadResponse(BaseModel):
    document_id: str
    document_name: str
    total_pages: int
    total_chunks: int
    indexed: int
    status: str
    message: str = "Document uploaded and indexed successfully"


class DocumentMetadata(BaseModel):
    document_id: str
    document_name: str
    page_number: Optional[int] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    total_pages: Optional[int] = None
    total_chunks: Optional[int] = None
    file_size: Optional[int] = None
    status: str


class DocumentListResponse(BaseModel):
    documents: List[DocumentMetadata]
    total: int


class DocumentDeleteResponse(BaseModel):
    document_id: str
    deleted_chunks: int
    status: str
    message: str


class PageDeleteRequest(BaseModel):
    page_numbers: List[int] = Field(..., description="List of page numbers to delete")


class PageUpdateRequest(BaseModel):
    page_numbers: List[int] = Field(..., description="List of page numbers to re-index")


# ── Report Models ──────────────────────────────────────────────────────────────

class ReportRequest(BaseModel):
    query: str = Field(..., min_length=3, max_length=5000, description="Research query")
    document_ids: Optional[List[str]] = Field(None, description="Filter to specific documents")
    use_react: bool = Field(True, description="Use ReAct reasoning framework")


class CitationModel(BaseModel):
    source_number: int
    document_name: str
    document_id: str
    page_number: Any
    chunk_id: str = ""


class ReActStep(BaseModel):
    thought: str
    action: str
    observation: str


class ReportResponse(BaseModel):
    report_id: str
    query: str
    title: str = ""
    status: str
    confidence_score: float = 0.0
    provider: str = ""
    model: str = ""
    citations: List[Dict[str, Any]] = []
    warnings: List[str] = []
    retrieved_chunks: int = 0
    reranked_chunks: int = 0
    compressed_chunks: int = 0
    react_steps: int = 0
    react_reasoning: List[Dict[str, str]] = []
    processing_time_s: float = 0.0
    pdf_url: Optional[str] = None
    message: Optional[str] = None
    content: Optional[str] = None


class ReportListItem(BaseModel):
    report_id: str
    query: str
    title: Optional[str]
    status: str
    confidence_score: float
    llm_provider: Optional[str]
    processing_time: Optional[float]
    created_at: Optional[str]
    pdf_url: Optional[str] = None


class ReportListResponse(BaseModel):
    reports: List[ReportListItem]
    total: int


# ── Search Models ─────────────────────────────────────────────────────────────

class SearchRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=2000)
    document_ids: Optional[List[str]] = None
    top_k: int = Field(default=5, ge=1, le=20)
    use_hybrid: bool = True


class SearchResultChunk(BaseModel):
    id: str
    content: str
    document_name: str
    page_number: Any
    score: float
    rerank_score: Optional[float] = None


class SearchResponse(BaseModel):
    query: str
    results: List[SearchResultChunk]
    total: int


# ── System Models ─────────────────────────────────────────────────────────────

class SystemStatsResponse(BaseModel):
    total_documents: int
    total_chunks_indexed: int
    total_reports: int
    vector_store_stats: Dict[str, Any]
    embedding_cache_stats: Dict[str, Any]
    chunk_cache_stats: Dict[str, Any]
    active_llm_provider: str
    active_embedding_model: str
    system_status: str


class FeedbackRequest(BaseModel):
    report_id: Optional[str] = None
    query: Optional[str] = None
    rating: Optional[int] = Field(None, ge=1, le=5)
    comment: Optional[str] = None
    helpful: Optional[bool] = None


class FeedbackResponse(BaseModel):
    feedback_id: str
    status: str
    message: str


class ErrorResponse(BaseModel):
    error: str
    detail: Optional[str] = None
    code: Optional[str] = None
