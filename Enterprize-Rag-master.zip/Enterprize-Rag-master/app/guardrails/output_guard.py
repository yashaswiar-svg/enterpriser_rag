"""
Output guardrails: validate LLM outputs against retrieved context.
Removes unsupported claims and attaches confidence scores.
"""
import re
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass, field

from app.utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class OutputValidationResult:
    is_valid: bool
    original_output: str
    validated_output: str
    confidence_score: float
    removed_claims: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    citations: List[Dict[str, Any]] = field(default_factory=list)


class OutputGuardrail:
    """
    Validates LLM output against retrieved context chunks.
    Strips unsupported claims and scores confidence.
    """

    def validate(
        self,
        llm_output: str,
        context_chunks: List[Dict[str, Any]],
        query: str = None,
    ) -> OutputValidationResult:
        """
        Validate LLM output against source chunks.
        """
        if not llm_output or not llm_output.strip():
            return OutputValidationResult(
                is_valid=False,
                original_output=llm_output or "",
                validated_output="No output generated.",
                confidence_score=0.0,
                warnings=["Empty LLM output"],
            )

        # Extract all context text
        context_texts = [c.get("content", "") for c in context_chunks]
        combined_context = " ".join(context_texts).lower()

        # Check for insufficient evidence claim
        if "insufficient evidence" in llm_output.lower():
            return OutputValidationResult(
                is_valid=True,
                original_output=llm_output,
                validated_output=llm_output,
                confidence_score=0.2,
                warnings=["Insufficient evidence in knowledge base"],
            )

        # Calculate confidence based on content overlap
        confidence = self._calculate_confidence(llm_output, context_texts)

        # Extract and validate citations
        citations = self._extract_citations(llm_output, context_chunks)

        # Check for hallucination indicators
        hallucination_warnings = self._detect_hallucinations(llm_output, combined_context)

        validated_output = llm_output
        removed_claims = []

        # If very low confidence, add warning
        if confidence < 0.3 and context_chunks:
            validated_output = (
                llm_output
                + "\n\n⚠️ Note: Some statements may not be directly supported by the retrieved documents."
            )
            hallucination_warnings.append("Low confidence: output may contain unsupported claims")

        return OutputValidationResult(
            is_valid=confidence > 0.2,
            original_output=llm_output,
            validated_output=validated_output,
            confidence_score=round(confidence, 3),
            removed_claims=removed_claims,
            warnings=hallucination_warnings,
            citations=citations,
        )

    def _calculate_confidence(self, output: str, context_texts: List[str]) -> float:
        """
        Estimate what fraction of the output's key terms appear in context.

        FIX: The 'Insufficient evidence' sentinel is checked first so it is
        never mis-scored as a hallucination by the word-overlap calculation.
        """
        # Sentinel: LLM correctly declared no evidence -> deliberate low
        # score so the caller can surface an informative UI warning.
        if "insufficient evidence" in output.lower():
            return 0.2

        if not context_texts:
            return 0.1

        output_words = set(re.findall(r'\b[a-zA-Z]{4,}\b', output.lower()))
        if not output_words:
            return 0.5

        context_words = set()
        for text in context_texts:
            context_words.update(re.findall(r'\b[a-zA-Z]{4,}\b', text.lower()))

        # Stop words to ignore
        stop_words = {
            "this", "that", "with", "from", "have", "been", "will", "they",
            "were", "their", "there", "then", "than", "also", "only", "when",
            "which", "would", "could", "should", "about", "after", "before",
            "into", "such", "both", "more", "some", "most", "over", "each",
            "through", "during", "including", "between", "provide", "based",
        }
        output_content = output_words - stop_words

        if not output_content:
            return 0.7  # Generic output, hard to verify

        overlap = len(output_content & context_words)
        confidence = min(1.0, overlap / len(output_content))

        return max(0.1, confidence)

    def _extract_citations(
        self, output: str, chunks: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Extract citation references from output."""
        citations = []
        seen = set()

        # Pattern: [Source N] Document: '...', Page: N
        source_pattern = re.compile(r'\[Source\s+(\d+)\]', re.IGNORECASE)
        matches = source_pattern.findall(output)

        for match in matches:
            idx = int(match) - 1
            if 0 <= idx < len(chunks):
                meta = chunks[idx].get("metadata", {})
                key = f"{meta.get('document_id', '')}:{meta.get('page_number', '')}"
                if key not in seen:
                    seen.add(key)
                    citations.append({
                        "source_number": int(match),
                        "document_name": meta.get("document_name", "Unknown"),
                        "document_id": meta.get("document_id", ""),
                        "page_number": meta.get("page_number", "?"),
                        "chunk_id": chunks[idx].get("id", ""),
                    })

        # Also extract from metadata of all chunks used
        for i, chunk in enumerate(chunks):
            meta = chunk.get("metadata", {})
            key = f"{meta.get('document_id', '')}:{meta.get('page_number', '')}"
            if key not in seen:
                seen.add(key)
                citations.append({
                    "source_number": i + 1,
                    "document_name": meta.get("document_name", "Unknown"),
                    "document_id": meta.get("document_id", ""),
                    "page_number": meta.get("page_number", "?"),
                    "chunk_id": chunk.get("id", ""),
                })

        return citations

    def _detect_hallucinations(self, output: str, context: str) -> List[str]:
        """Flag common hallucination markers."""
        warnings = []
        lower_output = output.lower()

        # Hedging phrases that indicate fabrication
        fabrication_phrases = [
            "i believe", "i think", "i assume", "probably",
            "as far as i know", "to my knowledge", "it is likely",
        ]
        for phrase in fabrication_phrases:
            if phrase in lower_output:
                warnings.append(f"Possible speculation detected: '{phrase}'")
                break

        # Claims about specific statistics not in context
        stat_pattern = re.compile(r'\b(\d+\.?\d*)\s*(%|percent|million|billion|thousand)\b', re.IGNORECASE)
        stats_in_output = stat_pattern.findall(output)
        if stats_in_output and not any(
            re.search(r'\b' + re.escape(s[0]) + r'\b', context) for s in stats_in_output
        ):
            warnings.append("Specific statistics in output may not be in source documents")

        return warnings


# Singleton
output_guardrail = OutputGuardrail()
