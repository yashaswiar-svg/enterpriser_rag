"""
Input guardrails: detect prompt injection, jailbreak, and role override attempts.
"""
import re
from typing import Tuple, List
from dataclasses import dataclass

from app.utils.logger import get_logger, log_security_event
from app.utils.database import get_db_session, SecurityEvent

logger = get_logger(__name__)


@dataclass
class GuardResult:
    is_safe: bool
    threat_type: str = None
    confidence: float = 0.0
    sanitized_input: str = None
    message: str = None


# Injection and jailbreak patterns
INJECTION_PATTERNS = [
    # Prompt injection
    (r"ignore\s+(all\s+)?(previous|prior|above|earlier)\s+(instructions?|prompts?|rules?|context)", "prompt_injection"),
    (r"disregard\s+(all\s+)?(previous|prior|above|earlier)", "prompt_injection"),
    (r"forget\s+(everything|all)\s+(you|i)\s*(were|was|have|told)", "prompt_injection"),
    (r"do\s+not\s+follow\s+(the\s+)?(previous|prior|above|earlier|any)", "prompt_injection"),
    (r"override\s+(the\s+)?(system|instructions?|prompt|rules?)", "prompt_injection"),
    (r"new\s+instructions?:", "prompt_injection"),
    (r"\[INST\].*\[/INST\]", "prompt_injection"),
    (r"<\|system\|>", "prompt_injection"),

    # System prompt extraction
    (r"(reveal|show|print|display|output|tell me|what is)\s+(your|the)\s+(system\s+)?prompt", "prompt_extraction"),
    (r"(reveal|show|print|display|output)\s+(your|the)\s+(instructions?|rules?|configuration)", "prompt_extraction"),
    (r"(what|show me|tell me)\s+(are\s+)?(your|the)\s+(secret|hidden|internal)\s+(instructions?|rules?)", "prompt_extraction"),
    (r"repeat\s+(the\s+)?(above|everything|all)\s+(back|verbatim)", "prompt_extraction"),

    # Developer/debug mode
    (r"(enable|activate|switch\s+to|enter)\s+(developer|debug|admin|sudo|god|DAN)\s+mode", "mode_switch"),
    (r"you\s+are\s+now\s+(in\s+)?(developer|debug|admin|jailbreak|unrestricted|uncensored)\s+mode", "mode_switch"),
    (r"act\s+as\s+if\s+(you\s+have\s+no|without\s+any)\s+(rules?|restrictions?|guidelines?|limits?)", "jailbreak"),

    # Role override
    (r"(pretend|act|behave|respond)\s+(you\s+are|as\s+if\s+you\s+are|as)\s+(a\s+)?(different|evil|unrestricted|unlimited)", "role_override"),
    (r"you\s+(are|must|should|will)\s+(now\s+)?(an?\s+)?(unrestricted|unlimited|uncensored|unfiltered)\s*(ai|assistant|model)?", "role_override"),
    (r"(without|no)\s+(any\s+)?(rules?|restrictions?|limits?|guidelines?|filters?)", "role_override"),
    (r"you\s+(must|should|will)\s+now\s+(ignore|disregard|forget)\s+(all\s+)?(rules?|restrictions?|safety)", "role_override"),
    (r"(DAN|JAILBREAK|STAN|DUDE|AIM|KEVIN)\s*(mode|prompt)", "jailbreak"),

    # Data exfiltration
    (r"(access|retrieve|fetch|get)\s+(the\s+)?(entire|all|complete)\s+(database|knowledge\s+base|corpus|data)", "data_exfil"),
    (r"dump\s+(the\s+)?(entire|all|complete)\s+(database|data|documents?)", "data_exfil"),
]

# Compile patterns
COMPILED_PATTERNS = [
    (re.compile(pattern, re.IGNORECASE | re.DOTALL), threat_type)
    for pattern, threat_type in INJECTION_PATTERNS
]


class InputGuardrail:
    """Validates and sanitizes user inputs against injection attacks."""

    def check(self, user_input: str, source_ip: str = None) -> GuardResult:
        """
        Check input for security threats.
        Returns GuardResult with is_safe flag and details.
        """
        if not user_input or not user_input.strip():
            return GuardResult(is_safe=False, threat_type="empty_input", message="Empty input")

        # Length check
        if len(user_input) > 10000:
            return GuardResult(
                is_safe=False,
                threat_type="input_too_long",
                message="Security violation detected.",
            )

        # Pattern matching
        for pattern, threat_type in COMPILED_PATTERNS:
            match = pattern.search(user_input)
            if match:
                log_security_event(
                    event_type=threat_type,
                    details=f"Pattern matched: '{match.group()[:100]}' in input: '{user_input[:200]}'",
                    severity="HIGH",
                )
                self._save_security_event(threat_type, source_ip, user_input)
                logger.warning(f"Input blocked: threat={threat_type}, ip={source_ip}")
                return GuardResult(
                    is_safe=False,
                    threat_type=threat_type,
                    confidence=0.95,
                    message="Security violation detected.",
                )

        # Heuristic checks
        heuristic_result = self._heuristic_check(user_input)
        if heuristic_result:
            log_security_event(
                event_type="heuristic_block",
                details=f"Heuristic threat: {heuristic_result} for input: '{user_input[:200]}'",
                severity="MEDIUM",
            )
            return GuardResult(
                is_safe=False,
                threat_type=heuristic_result,
                confidence=0.75,
                message="Security violation detected.",
            )

        return GuardResult(is_safe=True, sanitized_input=user_input.strip())

    def _heuristic_check(self, text: str) -> str | None:
        """Additional heuristic threat detection."""
        lower = text.lower()

        # Excessive special characters (injection attempt)
        special_ratio = sum(1 for c in text if c in '{}[]<>|\\;`') / max(len(text), 1)
        if special_ratio > 0.15:
            return "special_char_injection"

        # Multiple role/instruction keywords in sequence
        role_words = ["system:", "assistant:", "user:", "human:", "ai:", "[inst]", "###instruction"]
        if sum(1 for w in role_words if w in lower) >= 2:
            return "role_injection"

        return None

    def _save_security_event(self, event_type: str, source_ip: str, raw_input: str):
        """Persist security event to database."""
        db = get_db_session()
        try:
            event = SecurityEvent(
                event_type=event_type,
                severity="HIGH",
                source_ip=source_ip,
                raw_input=raw_input[:1000],  # Truncate
                details={"input_length": len(raw_input)},
            )
            db.add(event)
            db.commit()
        except Exception as e:
            logger.error(f"Failed to save security event: {e}")
        finally:
            db.close()


# Singleton
input_guardrail = InputGuardrail()
