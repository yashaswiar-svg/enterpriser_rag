"""
LLM Manager with primary (Gemini) → fallback (OpenAI) → raw chunks failsafe.
Application never crashes — always returns something.
"""
from typing import List, Dict, Any, Optional, Tuple
import time

from app.config.settings import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)


class LLMResult:
    def __init__(
        self,
        content: str,
        provider: str,
        model: str,
        latency_ms: float,
        is_fallback: bool = False,
        is_raw: bool = False,
    ):
        self.content = content
        self.provider = provider
        self.model = model
        self.latency_ms = latency_ms
        self.is_fallback = is_fallback
        self.is_raw = is_raw


class LLMManager:
    """
    Manages LLM providers with graceful failover chain:
    Gemini → OpenAI → Raw Retrieved Chunks
    """

    _instance = None

    @classmethod
    def get_instance(cls) -> "LLMManager":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._gemini = None
        self._openai = None
        self._init_providers()

    def _init_providers(self):
        """Initialize available providers."""
        if settings.GOOGLE_API_KEY:
            try:
                from app.llm.gemini_llm import GeminiLLM
                llm = GeminiLLM()
                # Quick validation — catch bad keys before first real request
                llm._model.generate_content("hi")
                self._gemini = llm
                logger.info("Gemini LLM ready")
            except Exception as e:
                logger.warning(f"Gemini init/validation failed, skipping: {e}")

        if settings.OPENAI_API_KEY:
            try:
                from app.llm.openai_llm import OpenAILLM
                self._openai = OpenAILLM()
                logger.info("OpenAI LLM ready")
            except Exception as e:
                logger.warning(f"OpenAI init failed: {e}")

        if not self._gemini and not self._openai:
            logger.warning("No LLM providers available — will return raw chunks only")

    def generate(
        self,
        prompt: str,
        system_prompt: str = None,
        context_chunks: List[Dict[str, Any]] = None,
    ) -> LLMResult:
        """
        Generate with full failover chain.
        Never raises — worst case returns raw retrieved chunks.
        """
        start = time.time()

        # Try Gemini (primary)
        if self._gemini:
            try:
                content = self._gemini.generate(prompt, system_prompt)
                latency = (time.time() - start) * 1000
                logger.info(f"Gemini response: {latency:.0f}ms")
                return LLMResult(
                    content=content,
                    provider="gemini",
                    model=settings.GEMINI_MODEL,
                    latency_ms=latency,
                )
            except Exception as e:
                logger.warning(f"Gemini failed, trying OpenAI: {e}")

        # Try OpenAI (fallback)
        if self._openai:
            try:
                content = self._openai.generate(prompt, system_prompt)
                latency = (time.time() - start) * 1000
                logger.info(f"OpenAI fallback response: {latency:.0f}ms")
                return LLMResult(
                    content=content,
                    provider="openai",
                    model=settings.OPENAI_MODEL,
                    latency_ms=latency,
                    is_fallback=True,
                )
            except Exception as e:
                logger.warning(f"OpenAI also failed: {e}")

        # Last resort: return raw chunks
        latency = (time.time() - start) * 1000
        raw_content = self._format_raw_chunks(context_chunks or [])
        logger.warning("All LLMs failed — returning raw retrieved chunks")
        return LLMResult(
            content=raw_content,
            provider="raw_retrieval",
            model="none",
            latency_ms=latency,
            is_raw=True,
        )

    async def agenerate(
        self,
        prompt: str,
        system_prompt: str = None,
        context_chunks: List[Dict[str, Any]] = None,
    ) -> LLMResult:
        """Async generate with failover."""
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None, self.generate, prompt, system_prompt, context_chunks
        )

    def _format_raw_chunks(self, chunks: List[Dict[str, Any]]) -> str:
        """Format raw chunks as fallback response."""
        if not chunks:
            return (
                "I couldn't find any relevant information in the knowledge base "
                "to answer your question.\n\n"
                "**Recommendations:**\n"
                "- Upload relevant documents using the Documents tab\n"
                "- Try rephrasing your query\n"
                "- Check that your documents have been successfully indexed"
            )

        lines = [
            "Based on the retrieved documents, here is the information I found:\n"
        ]
        seen = set()
        for i, chunk in enumerate(chunks[:5], start=1):
            meta = chunk.get("metadata", {})
            doc_name = meta.get("document_name", "Unknown")
            page = meta.get("page_number", "?")
            content = chunk.get("content", "").strip()
            if not content:
                continue
            key = f"{doc_name}_p{page}" if page else doc_name
            if key in seen:
                continue
            seen.add(key)
            lines.append(f"**From {doc_name} (Page {page}):**")
            lines.append("")
            lines.append(content)
            lines.append("")

        if len(lines) == 1:
            return "No relevant information found in the knowledge base for your query."

        lines.append("---")
        lines.append("### Sources")
        for i, chunk in enumerate(chunks[:5], start=1):
            meta = chunk.get("metadata", {})
            doc_name = meta.get("document_name", "Unknown")
            page = meta.get("page_number", "?")
            lines.append(f"- {doc_name} (Page {page})")

        return "\n".join(lines)

    @property
    def active_provider(self) -> str:
        if self._gemini:
            return "gemini"
        if self._openai:
            return "openai"
        return "none"


# Singleton
llm_manager = LLMManager.get_instance()
