"""
ReAct (Reasoning + Acting) agent for structured research generation.
Implements: Thought → Action → Observation → Final Answer cycle.
"""
import re
import time
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field

from app.llm.llm_manager import LLMManager, llm_manager, LLMResult
from app.llm.prompts import REACT_SYSTEM_PROMPT, REACT_STEP_PROMPT, SYSTEM_PROMPT
from app.retrieval.context_compressor import context_compressor
from app.config.settings import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class ReActStep:
    thought: str = ""
    action: str = ""
    observation: str = ""


@dataclass
class ReActResult:
    steps: List[ReActStep] = field(default_factory=list)
    final_answer: str = ""
    provider: str = ""
    model: str = ""
    latency_ms: float = 0.0
    context_chunks: List[Dict] = field(default_factory=list)
    is_fallback: bool = False


class ReActAgent:
    """
    Implements ReAct reasoning framework for research generation.
    Uses retrieved context to reason step-by-step before answering.
    """

    def __init__(self, llm: LLMManager = None):
        self.llm = llm or llm_manager

    def run(
        self,
        query: str,
        context_chunks: List[Dict[str, Any]],
        max_steps: int = 4,
    ) -> ReActResult:
        """
        Execute ReAct reasoning loop.
        Returns structured result with reasoning steps and final answer.
        """
        start = time.time()

        if not context_chunks:
            return ReActResult(
                final_answer="Insufficient evidence found in knowledge base.",
                provider="none",
                latency_ms=0,
            )

        # Compress context
        compressed_chunks = context_compressor.compress(context_chunks, query)
        context_str = context_compressor.format_context(compressed_chunks)

        # Build ReAct prompt
        react_prompt = REACT_STEP_PROMPT.format(
            query=query,
            context=context_str,
        )

        # Generate ReAct response
        llm_result = self.llm.generate(
            prompt=react_prompt,
            system_prompt=REACT_SYSTEM_PROMPT,
            context_chunks=context_chunks,
        )

        # Parse ReAct steps
        steps, final_answer = self._parse_react_output(llm_result.content)

        latency = (time.time() - start) * 1000
        logger.info(
            f"ReAct completed: {len(steps)} steps, provider={llm_result.provider}, "
            f"latency={latency:.0f}ms"
        )

        return ReActResult(
            steps=steps,
            final_answer=final_answer or llm_result.content,
            provider=llm_result.provider,
            model=llm_result.model,
            latency_ms=latency,
            context_chunks=compressed_chunks,
            is_fallback=llm_result.is_fallback or llm_result.is_raw,
        )

    async def arun(
        self,
        query: str,
        context_chunks: List[Dict[str, Any]],
        max_steps: int = 4,
    ) -> ReActResult:
        """Async ReAct execution."""
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.run, query, context_chunks, max_steps)

    def _parse_react_output(self, output: str) -> Tuple[List[ReActStep], str]:
        """Parse LLM output into ReAct steps and final answer."""
        steps = []
        final_answer = ""

        # Extract final answer
        final_pattern = re.compile(
            r'(?:Final Answer:|FINAL ANSWER:|## Final Answer)(.*?)(?=$|\n##)',
            re.IGNORECASE | re.DOTALL
        )
        final_match = final_pattern.search(output)
        if final_match:
            final_answer = final_match.group(1).strip()
            output_before_final = output[:final_match.start()]
        else:
            output_before_final = output
            final_answer = output.strip()

        # Parse Thought/Action/Observation blocks
        thought_pattern = re.compile(r'Thought\s*\d*:\s*(.*?)(?=Action\s*\d*:|Observation\s*\d*:|Final Answer:|$)', re.DOTALL | re.IGNORECASE)
        action_pattern = re.compile(r'Action\s*\d*:\s*(.*?)(?=Thought\s*\d*:|Observation\s*\d*:|Final Answer:|$)', re.DOTALL | re.IGNORECASE)
        obs_pattern = re.compile(r'Observation\s*\d*:\s*(.*?)(?=Thought\s*\d*:|Action\s*\d*:|Final Answer:|$)', re.DOTALL | re.IGNORECASE)

        thoughts = [m.group(1).strip() for m in thought_pattern.finditer(output_before_final)]
        actions = [m.group(1).strip() for m in action_pattern.finditer(output_before_final)]
        observations = [m.group(1).strip() for m in obs_pattern.finditer(output_before_final)]

        max_steps = max(len(thoughts), len(actions), len(observations))
        for i in range(max_steps):
            step = ReActStep(
                thought=thoughts[i] if i < len(thoughts) else "",
                action=actions[i] if i < len(actions) else "",
                observation=observations[i] if i < len(observations) else "",
            )
            if step.thought or step.action or step.observation:
                steps.append(step)

        if not steps and not final_answer:
            final_answer = output.strip()

        return steps, final_answer

    def generate_report_content(
        self,
        query: str,
        context_chunks: List[Dict[str, Any]],
    ) -> Tuple[str, LLMResult]:
        """
        Generate full structured report content using LLM.
        Returns (report_text, llm_result).
        """
        from app.llm.prompts import REPORT_GENERATION_PROMPT

        compressed_chunks = context_compressor.compress(context_chunks, query)
        context_str = context_compressor.format_context(compressed_chunks)

        report_prompt = REPORT_GENERATION_PROMPT.format(
            context=context_str,
            query=query,
        )

        llm_result = self.llm.generate(
            prompt=report_prompt,
            system_prompt=SYSTEM_PROMPT,
            context_chunks=context_chunks,
        )

        return llm_result.content, llm_result

    def synthesize(
        self,
        query: str,
        draft_answer: str,
        context_chunks: List[Dict[str, Any]],
    ) -> str:
        """
        Post-ReAct polishing pass.

        Takes the ReAct final answer (which may still contain reasoning
        scaffolding or raw bullet points) and asks the LLM to produce a
        single, publication-quality answer that:
          - keeps ONLY facts supported by the retrieved context
          - replaces every [Source N] reference with the real inline format
            [Document Name, Page X]
          - removes Thought/Action/Observation scaffolding
          - is token-efficient (no padding or repetition)

        Returns the polished answer string, or the original draft if the
        LLM call fails.
        """
        from app.llm.prompts import SYNTHESIS_PROMPT, SYNTHESIS_SYSTEM_PROMPT

        if not draft_answer or not draft_answer.strip():
            return draft_answer

        # If it's already an "insufficient evidence" signal, don't polish
        if "insufficient evidence" in draft_answer.lower():
            return draft_answer

        compressed_chunks = context_compressor.compress(context_chunks, query)
        context_str = context_compressor.format_context(compressed_chunks)

        synthesis_prompt = SYNTHESIS_PROMPT.format(
            query=query,
            context=context_str,
            draft_answer=draft_answer,
        )

        try:
            llm_result = self.llm.generate(
                prompt=synthesis_prompt,
                system_prompt=SYNTHESIS_SYSTEM_PROMPT,
                context_chunks=context_chunks,
            )
            polished = llm_result.content.strip()
            logger.info(
                f"Synthesis complete: provider={llm_result.provider}, "
                f"{len(draft_answer)} → {len(polished)} chars"
            )
            return polished if polished else draft_answer
        except Exception as e:
            logger.warning(f"Synthesis pass failed, returning draft: {e}")
            return draft_answer


# Singleton
react_agent = ReActAgent()
