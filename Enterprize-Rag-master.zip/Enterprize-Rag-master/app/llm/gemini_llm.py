"""
Google Gemini 2.5 Flash LLM provider.
"""
from typing import Optional, AsyncGenerator
import google.generativeai as genai

from app.config.settings import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)


class GeminiLLM:
    """Google Gemini LLM wrapper."""

    def __init__(self):
        if not settings.GOOGLE_API_KEY:
            raise ValueError("GOOGLE_API_KEY not configured")
        genai.configure(api_key=settings.GOOGLE_API_KEY)
        self.model_name = settings.GEMINI_MODEL
        self._model = genai.GenerativeModel(
            model_name=self.model_name,
            generation_config=genai.types.GenerationConfig(
                temperature=settings.LLM_TEMPERATURE,
                max_output_tokens=settings.LLM_MAX_TOKENS,
            ),
            safety_settings=[
                {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_ONLY_HIGH"},
                {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_ONLY_HIGH"},
                {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_ONLY_HIGH"},
                {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_ONLY_HIGH"},
            ],
        )
        logger.info(f"GeminiLLM initialized: {self.model_name}")

    def generate(self, prompt: str, system_prompt: str = None) -> str:
        """Generate a response."""
        try:
            if system_prompt:
                model = genai.GenerativeModel(
                    model_name=self.model_name,
                    system_instruction=system_prompt,
                    generation_config=genai.types.GenerationConfig(
                        temperature=settings.LLM_TEMPERATURE,
                        max_output_tokens=settings.LLM_MAX_TOKENS,
                    ),
                )
                response = model.generate_content(prompt)
            else:
                response = self._model.generate_content(prompt)

            return response.text
        except Exception as e:
            logger.error(f"Gemini generate failed: {e}")
            raise

    async def agenerate(self, prompt: str, system_prompt: str = None) -> str:
        """Async generation."""
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.generate, prompt, system_prompt)

    def generate_with_history(
        self,
        messages: list,
        system_prompt: str = None,
    ) -> str:
        """Generate with conversation history."""
        try:
            model = genai.GenerativeModel(
                model_name=self.model_name,
                system_instruction=system_prompt or "",
                generation_config=genai.types.GenerationConfig(
                    temperature=settings.LLM_TEMPERATURE,
                    max_output_tokens=settings.LLM_MAX_TOKENS,
                ),
            )
            chat = model.start_chat(history=messages[:-1] if len(messages) > 1 else [])
            response = chat.send_message(messages[-1]["content"] if messages else "")
            return response.text
        except Exception as e:
            logger.error(f"Gemini history generate failed: {e}")
            raise
