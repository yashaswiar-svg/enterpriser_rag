"""
OpenAI GPT-4o LLM provider (fallback).
"""
from typing import Optional, List, Dict

from app.config.settings import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)


class OpenAILLM:
    """OpenAI GPT-4o wrapper as fallback LLM."""

    def __init__(self):
        if not settings.OPENAI_API_KEY:
            raise ValueError("OPENAI_API_KEY not configured")
        from openai import OpenAI
        self.client = OpenAI(api_key=settings.OPENAI_API_KEY)
        self.model_name = settings.OPENAI_MODEL
        logger.info(f"OpenAILLM initialized: {self.model_name}")

    def generate(self, prompt: str, system_prompt: str = None) -> str:
        """Generate a response."""
        try:
            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})

            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=messages,
                temperature=settings.LLM_TEMPERATURE,
                max_tokens=settings.LLM_MAX_TOKENS,
                timeout=settings.LLM_TIMEOUT,
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"OpenAI generate failed: {e}")
            raise

    async def agenerate(self, prompt: str, system_prompt: str = None) -> str:
        """Async generation."""
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.generate, prompt, system_prompt)

    def generate_with_history(
        self,
        messages: List[Dict],
        system_prompt: str = None,
    ) -> str:
        """Generate with conversation history."""
        try:
            formatted = []
            if system_prompt:
                formatted.append({"role": "system", "content": system_prompt})
            for msg in messages:
                role = msg.get("role", "user")
                if role == "model":
                    role = "assistant"
                formatted.append({"role": role, "content": msg.get("content", "")})

            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=formatted,
                temperature=settings.LLM_TEMPERATURE,
                max_tokens=settings.LLM_MAX_TOKENS,
                timeout=settings.LLM_TIMEOUT,
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"OpenAI history generate failed: {e}")
            raise
