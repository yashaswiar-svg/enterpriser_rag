"""
ChromaDB vector store implementation with persistent storage.
Supports 100k+ chunks with incremental updates.
"""
import os
from typing import List, Dict, Any, Optional, Tuple
import chromadb
from chromadb.config import Settings as ChromaSettings

from app.config.settings import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)


class ChromaVectorStore:
    """ChromaDB wrapper for persistent vector storage."""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        os.makedirs(settings.CHROMA_PERSIST_DIR, exist_ok=True)
        self.client = chromadb.PersistentClient(
            path=settings.CHROMA_PERSIST_DIR,
            settings=ChromaSettings(anonymized_telemetry=False),
        )
        self.collection = self.client.get_or_create_collection(
            name=settings.CHROMA_COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )
        self._initialized = True
        logger.info(
            f"ChromaDB initialized: collection={settings.CHROMA_COLLECTION_NAME}, "
            f"count={self.collection.count()}"
        )

    def add_documents(
        self,
        texts: List[str],
        embeddings: List[List[float]],
        metadatas: List[Dict[str, Any]],
        ids: List[str],
    ):
        """Add or update documents in the collection."""
        if not texts:
            return

        # ChromaDB requires all metadata values to be str/int/float/bool
        clean_metadatas = []
        for meta in metadatas:
            clean = {}
            for k, v in meta.items():
                if isinstance(v, (str, int, float, bool)):
                    clean[k] = v
                else:
                    clean[k] = str(v)
            clean_metadatas.append(clean)

        self.collection.upsert(
            documents=texts,
            embeddings=embeddings,
            metadatas=clean_metadatas,
            ids=ids,
        )
        logger.debug(f"Upserted {len(texts)} documents to ChromaDB")

    def _count_matching(self, where: Optional[Dict]) -> int:
        """Count chunks matching an optional where-filter without fetching content."""
        try:
            if where:
                res = self.collection.get(where=where, include=[])
            else:
                res = self.collection.get(include=[])
            return len(res.get("ids", []))
        except Exception:
            return self.collection.count()

    def query(
        self,
        query_embedding: List[float],
        n_results: int = 20,
        where: Optional[Dict] = None,
    ) -> List[Dict[str, Any]]:
        """
        Query vector store by embedding.
        Returns list of result dicts with id, content, metadata, distance.

        FIX: n_results is clamped against the number of chunks that actually
        match the where-filter (not the total collection count), preventing
        ChromaDB from raising 'Number of requested results N is greater than
        number of elements in index M' when a scoped query targets a small
        document.
        """
        total_matching = self._count_matching(where)
        if total_matching == 0:
            return []

        safe_n = min(n_results, total_matching)

        kwargs = {
            "query_embeddings": [query_embedding],
            "n_results": safe_n,
            "include": ["documents", "metadatas", "distances"],
        }
        if where:
            kwargs["where"] = where

        try:
            results = self.collection.query(**kwargs)
        except Exception as e:
            logger.error(f"ChromaDB query failed (n_results={safe_n}, where={where}): {e}")
            return []

        hits = []
        if results and results["ids"]:
            for i, doc_id in enumerate(results["ids"][0]):
                hits.append({
                    "id": doc_id,
                    "content": results["documents"][0][i],
                    "metadata": results["metadatas"][0][i],
                    "distance": results["distances"][0][i],
                    "score": 1 - results["distances"][0][i],  # cosine similarity
                })

        return hits

    def delete_documents(self, ids: List[str]):
        """Delete documents by IDs."""
        if not ids:
            return
        # Process in batches to avoid limits
        batch_size = 1000
        for i in range(0, len(ids), batch_size):
            batch = ids[i: i + batch_size]
            try:
                self.collection.delete(ids=batch)
            except Exception as e:
                logger.warning(f"Delete batch failed: {e}")
        logger.debug(f"Deleted {len(ids)} documents from ChromaDB")

    def delete_by_document_id(self, document_id: str):
        """Delete all chunks for a given document_id using metadata filter."""
        try:
            self.collection.delete(where={"document_id": document_id})
            logger.info(f"Deleted all chunks for document: {document_id}")
        except Exception as e:
            logger.error(f"Delete by document_id failed: {e}")
            raise

    def get_document_ids(self) -> List[str]:
        """Get all unique document IDs stored."""
        try:
            result = self.collection.get(include=["metadatas"])
            doc_ids = set()
            for meta in result.get("metadatas", []):
                if meta and "document_id" in meta:
                    doc_ids.add(meta["document_id"])
            return list(doc_ids)
        except Exception as e:
            logger.error(f"Get document IDs failed: {e}")
            return []

    def count(self) -> int:
        """Return total number of indexed chunks."""
        return self.collection.count()

    def get_collection_stats(self) -> Dict[str, Any]:
        """Return collection statistics."""
        count = self.collection.count()
        doc_ids = self.get_document_ids()
        return {
            "total_chunks": count,
            "unique_documents": len(doc_ids),
            "collection_name": settings.CHROMA_COLLECTION_NAME,
            "persist_dir": settings.CHROMA_PERSIST_DIR,
        }
