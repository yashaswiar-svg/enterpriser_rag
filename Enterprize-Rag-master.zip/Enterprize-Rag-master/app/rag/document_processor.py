"""
Document ingestion, splitting, and preprocessing pipeline.
Supports PDF, DOCX, TXT with async batch processing.
"""
import os
import uuid
import hashlib
import asyncio
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor

from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document as LangchainDoc

from app.config.settings import settings
from app.utils.logger import get_logger
from app.utils.database import get_db_session, Document, Chunk

logger = get_logger(__name__)


class DocumentChunk:
    """Represents a processed document chunk."""

    def __init__(
        self,
        chunk_id: str,
        document_id: str,
        document_name: str,
        page_number: int,
        chunk_index: int,
        content: str,
        metadata: Dict[str, Any] = None,
    ):
        self.chunk_id = chunk_id
        self.document_id = document_id
        self.document_name = document_name
        self.page_number = page_number
        self.chunk_index = chunk_index
        self.content = content
        self.metadata = metadata or {}
        self.content_hash = hashlib.md5(content.encode()).hexdigest()
        self.token_count = len(content.split())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "chunk_id": self.chunk_id,
            "document_id": self.document_id,
            "document_name": self.document_name,
            "page_number": self.page_number,
            "chunk_index": self.chunk_index,
            "content": self.content,
            "content_hash": self.content_hash,
            "token_count": self.token_count,
            "metadata": self.metadata,
        }


class DocumentProcessor:
    """Handles document ingestion and chunking."""

    def __init__(self):
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=settings.CHUNK_SIZE,
            chunk_overlap=settings.CHUNK_OVERLAP,
            length_function=len,
            separators=["\n\n", "\n", ". ", " ", ""],
        )
        self.executor = ThreadPoolExecutor(max_workers=settings.WORKER_THREADS)
        logger.info("DocumentProcessor initialized")

    def _extract_text_from_pdf(self, file_path: str) -> List[Tuple[int, str]]:
        """Extract text from PDF with page numbers. Returns list of (page_num, text)."""
        pages = []
        try:
            import pypdf
            with open(file_path, "rb") as f:
                reader = pypdf.PdfReader(f)
                for page_num, page in enumerate(reader.pages, start=1):
                    text = page.extract_text() or ""
                    if text.strip():
                        pages.append((page_num, text))
            logger.info(f"Extracted {len(pages)} pages from PDF: {file_path}")
        except Exception as e:
            logger.warning(f"pypdf failed for {file_path}, trying unstructured: {e}")
            try:
                from unstructured.partition.pdf import partition_pdf
                elements = partition_pdf(filename=file_path)
                page_texts: Dict[int, List[str]] = {}
                for el in elements:
                    pn = getattr(el.metadata, "page_number", 1) or 1
                    page_texts.setdefault(pn, []).append(str(el))
                for pn in sorted(page_texts):
                    pages.append((pn, "\n".join(page_texts[pn])))
                logger.info(f"Unstructured extracted {len(pages)} pages from: {file_path}")
            except Exception as e2:
                logger.error(f"All PDF extractors failed for {file_path}: {e2}")
                raise

        return pages

    def _extract_text_from_file(self, file_path: str) -> List[Tuple[int, str]]:
        """Extract text from various file types."""
        ext = Path(file_path).suffix.lower()

        if ext == ".pdf":
            return self._extract_text_from_pdf(file_path)
        elif ext in [".txt", ".md"]:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
            return [(1, content)]
        elif ext in [".docx", ".doc"]:
            try:
                from docx import Document as DocxDocument
                doc = DocxDocument(file_path)
                text = "\n".join([para.text for para in doc.paragraphs if para.text])
                return [(1, text)]
            except Exception as e:
                logger.error(f"DOCX extraction failed: {e}")
                raise
        else:
            raise ValueError(f"Unsupported file type: {ext}")

    def process_document(
        self, file_path: str, document_id: str = None, document_name: str = None
    ) -> Tuple[str, List[DocumentChunk]]:
        """Process a document and return (document_id, chunks)."""
        document_id = document_id or str(uuid.uuid4())
        document_name = document_name or Path(file_path).name

        logger.info(f"Processing document: {document_name} (id={document_id})")

        # Extract pages
        pages = self._extract_text_from_file(file_path)
        chunks: List[DocumentChunk] = []
        chunk_index = 0

        for page_num, page_text in pages:
            if not page_text.strip():
                continue

            # Split page into chunks
            page_chunks = self.text_splitter.split_text(page_text)

            for chunk_text in page_chunks:
                if not chunk_text.strip():
                    continue
                chunk_id = f"{document_id}_p{page_num}_c{chunk_index}"
                chunk = DocumentChunk(
                    chunk_id=chunk_id,
                    document_id=document_id,
                    document_name=document_name,
                    page_number=page_num,
                    chunk_index=chunk_index,
                    content=chunk_text.strip(),
                    metadata={
                        "document_id": document_id,
                        "document_name": document_name,
                        "page_number": page_num,
                        "chunk_index": chunk_index,
                        "created_at": datetime.utcnow().isoformat(),
                    },
                )
                chunks.append(chunk)
                chunk_index += 1

        logger.info(f"Document {document_name}: {len(pages)} pages → {len(chunks)} chunks")
        return document_id, chunks

    async def aprocess_document(
        self, file_path: str, document_id: str = None, document_name: str = None
    ) -> Tuple[str, List[DocumentChunk]]:
        """Async document processing."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            self.executor,
            self.process_document,
            file_path,
            document_id,
            document_name,
        )

    def process_document_pages(
        self,
        file_path: str,
        document_id: str,
        document_name: str,
        page_numbers: List[int],
    ) -> List[DocumentChunk]:
        """Re-process specific pages only (for partial updates)."""
        pages = self._extract_text_from_file(file_path)
        target_pages = {pn: text for pn, text in pages if pn in page_numbers}

        chunks = []
        for page_num in page_numbers:
            if page_num not in target_pages:
                continue
            page_text = target_pages[page_num]
            page_chunks = self.text_splitter.split_text(page_text)
            for ci, chunk_text in enumerate(page_chunks):
                if not chunk_text.strip():
                    continue
                chunk_id = f"{document_id}_p{page_num}_c{ci}"
                chunk = DocumentChunk(
                    chunk_id=chunk_id,
                    document_id=document_id,
                    document_name=document_name,
                    page_number=page_num,
                    chunk_index=ci,
                    content=chunk_text.strip(),
                    metadata={
                        "document_id": document_id,
                        "document_name": document_name,
                        "page_number": page_num,
                        "chunk_index": ci,
                        "updated_at": datetime.utcnow().isoformat(),
                    },
                )
                chunks.append(chunk)

        logger.info(f"Re-processed {len(page_numbers)} pages → {len(chunks)} chunks")
        return chunks

    def save_chunks_to_db(self, document_id: str, chunks: List[DocumentChunk]):
        """Persist chunks to the SQL database."""
        db = get_db_session()
        try:
            for chunk in chunks:
                db_chunk = Chunk(
                    chunk_id=chunk.chunk_id,
                    document_id=chunk.document_id,
                    document_name=chunk.document_name,
                    page_number=chunk.page_number,
                    chunk_index=chunk.chunk_index,
                    content=chunk.content,
                    content_hash=chunk.content_hash,
                    token_count=chunk.token_count,
                    is_indexed=False,
                )
                db.merge(db_chunk)
            db.commit()
            logger.debug(f"Saved {len(chunks)} chunks to DB for doc {document_id}")
        except Exception as e:
            db.rollback()
            logger.error(f"Failed to save chunks: {e}")
            raise
        finally:
            db.close()


# Singleton
document_processor = DocumentProcessor()
