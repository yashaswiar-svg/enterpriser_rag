"""
Full document ingestion pipeline: upload → process → embed → index.
Supports incremental indexing and background async workers.
"""
import os
import uuid
import asyncio
import shutil
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional

from app.rag.document_processor import DocumentProcessor, DocumentChunk, document_processor
from app.vectorstore.chroma_store import ChromaVectorStore
from app.embeddings.embedding_manager import embedding_manager
from app.config.settings import settings
from app.utils.logger import get_logger
from app.utils.database import get_db_session, Document, Chunk, AuditLog

logger = get_logger(__name__)


def _invalidate_retriever():
    """
    Invalidate the BM25 index and chunk cache in the hybrid retriever
    after any document mutation (upload / delete / page update).
    Imported lazily to avoid circular imports at module load time.
    """
    try:
        from app.retrieval.hybrid_retriever import hybrid_retriever
        hybrid_retriever.invalidate_bm25()
    except Exception as e:
        logger.warning(f"BM25 invalidation failed (non-fatal): {e}")


class IngestionPipeline:
    """
    Full pipeline: file → chunks → embeddings → vector store.
    Handles incremental indexing — never rebuilds entire DB.
    """

    def __init__(self):
        self.processor = document_processor
        self.vector_store = ChromaVectorStore()
        logger.info("IngestionPipeline initialized")

    def _save_uploaded_file(self, file_content: bytes, filename: str) -> str:
        """Save uploaded file to disk and return path."""
        os.makedirs(settings.DOCUMENTS_DIR, exist_ok=True)
        # Sanitize filename
        safe_name = Path(filename).name.replace(" ", "_")
        dest_path = os.path.join(settings.DOCUMENTS_DIR, safe_name)

        # Handle name collisions
        base, ext = os.path.splitext(safe_name)
        counter = 1
        while os.path.exists(dest_path):
            dest_path = os.path.join(settings.DOCUMENTS_DIR, f"{base}_{counter}{ext}")
            counter += 1

        with open(dest_path, "wb") as f:
            f.write(file_content)
        logger.info(f"Saved uploaded file to: {dest_path}")
        return dest_path

    def _register_document(self, document_id: str, document_name: str, file_path: str, file_size: int) -> Document:
        """Register document in SQL DB with status=processing."""
        db = get_db_session()
        try:
            doc = Document(
                document_id=document_id,
                document_name=document_name,
                file_path=file_path,
                file_size=file_size,
                status="processing",
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )
            merged = db.merge(doc)
            db.commit()
            db.refresh(merged)
            logger.info(f"Registered document: {document_id}")
            # detach before closing session
            doc_id = merged.document_id
            doc_name = merged.document_name
        except Exception as e:
            db.rollback()
            raise
        finally:
            db.close()
        return document_id

    def _update_document_status(
        self, document_id: str, status: str, total_pages: int = None,
        total_chunks: int = None, error: str = None
    ):
        db = get_db_session()
        try:
            doc = db.query(Document).filter(Document.document_id == document_id).first()
            if doc:
                doc.status = status
                doc.updated_at = datetime.utcnow()
                if total_pages is not None:
                    doc.total_pages = total_pages
                if total_chunks is not None:
                    doc.total_chunks = total_chunks
                if error:
                    doc.error_message = error
                db.commit()
        except Exception as e:
            db.rollback()
            logger.error(f"Failed to update document status: {e}")
        finally:
            db.close()

    def _embed_and_index_chunks(self, chunks: List[DocumentChunk]) -> int:
        """Embed chunks and add to vector store. Returns count indexed."""
        if not chunks:
            return 0

        batch_size = settings.BATCH_SIZE
        indexed = 0

        for batch_start in range(0, len(chunks), batch_size):
            batch = chunks[batch_start: batch_start + batch_size]
            texts = [c.content for c in batch]
            metadatas = [c.metadata for c in batch]
            ids = [c.chunk_id for c in batch]

            try:
                embeddings = embedding_manager.embed_documents(texts)
                self.vector_store.add_documents(
                    texts=texts,
                    embeddings=embeddings,
                    metadatas=metadatas,
                    ids=ids,
                )
                indexed += len(batch)
                logger.debug(f"Indexed batch {batch_start}–{batch_start + len(batch)}")
            except Exception as e:
                logger.error(f"Batch indexing failed at {batch_start}: {e}")
                raise

        return indexed

    def ingest_document(
        self,
        file_content: bytes,
        filename: str,
        document_id: str = None,
    ) -> Dict[str, Any]:
        """
        Main ingestion entry point.
        Returns metadata dict with document_id, chunks, status.
        """
        document_id = document_id or str(uuid.uuid4())
        file_path = self._save_uploaded_file(file_content, filename)
        file_size = len(file_content)
        document_name = Path(filename).name

        self._register_document(document_id, document_name, file_path, file_size)

        try:
            # Process document into chunks
            _, chunks = self.processor.process_document(file_path, document_id, document_name)
            total_pages = max((c.page_number for c in chunks), default=0)

            # Save chunks to DB
            self.processor.save_chunks_to_db(document_id, chunks)

            # Embed and index
            indexed = self._embed_and_index_chunks(chunks)

            # Mark chunks as indexed in DB
            db = get_db_session()
            try:
                db.query(Chunk).filter(Chunk.document_id == document_id).update(
                    {"is_indexed": True, "embedding_model": embedding_manager.model_name}
                )
                db.commit()
            finally:
                db.close()

            self._update_document_status(
                document_id, "indexed", total_pages=total_pages, total_chunks=len(chunks)
            )

            # Audit log
            self._log_audit("document_ingested", "document", document_id, {
                "document_name": document_name,
                "total_pages": total_pages,
                "total_chunks": len(chunks),
                "indexed": indexed,
            })

            logger.info(f"Ingestion complete: {document_name} → {len(chunks)} chunks indexed")

            # Invalidate BM25 so next query sees the new document
            _invalidate_retriever()

            return {
                "document_id": document_id,
                "document_name": document_name,
                "total_pages": total_pages,
                "total_chunks": len(chunks),
                "indexed": indexed,
                "status": "indexed",
            }

        except Exception as e:
            self._update_document_status(document_id, "failed", error=str(e))
            logger.error(f"Ingestion failed for {filename}: {e}")
            raise

    async def aingest_document(
        self,
        file_content: bytes,
        filename: str,
        document_id: str = None,
    ) -> Dict[str, Any]:
        """Async ingestion wrapper."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.ingest_document, file_content, filename, document_id)

    def update_document_pages(
        self, document_id: str, page_numbers: List[int]
    ) -> Dict[str, Any]:
        """
        Re-index specific pages only.
        Used for partial document updates.
        """
        db = get_db_session()
        try:
            doc = db.query(Document).filter(Document.document_id == document_id).first()
            if not doc:
                raise ValueError(f"Document {document_id} not found")
            file_path = doc.file_path
            document_name = doc.document_name
        finally:
            db.close()

        # Delete old chunks for these pages from vector store
        old_chunk_ids = self._get_chunk_ids_for_pages(document_id, page_numbers)
        if old_chunk_ids:
            self.vector_store.delete_documents(old_chunk_ids)

        # Re-process pages
        new_chunks = self.processor.process_document_pages(
            file_path, document_id, document_name, page_numbers
        )

        # Save and index new chunks
        self.processor.save_chunks_to_db(document_id, new_chunks)
        indexed = self._embed_and_index_chunks(new_chunks)

        self._update_document_status(document_id, "indexed")
        logger.info(f"Updated {len(page_numbers)} pages → {len(new_chunks)} new chunks")

        # Invalidate BM25 so next query sees the updated pages
        _invalidate_retriever()

        return {
            "document_id": document_id,
            "pages_updated": page_numbers,
            "new_chunks": len(new_chunks),
            "indexed": indexed,
        }

    def delete_document(self, document_id: str) -> Dict[str, Any]:
        """Delete a document and all its chunks from all stores."""
        db = get_db_session()
        try:
            doc = db.query(Document).filter(Document.document_id == document_id).first()
            if not doc:
                raise ValueError(f"Document {document_id} not found")

            # Get all chunk IDs
            chunk_ids = [c.chunk_id for c in db.query(Chunk).filter(
                Chunk.document_id == document_id
            ).all()]

            # Delete from vector store
            if chunk_ids:
                self.vector_store.delete_documents(chunk_ids)

            # Delete file if exists
            if doc.file_path and os.path.exists(doc.file_path):
                os.remove(doc.file_path)

            # Delete from SQL DB (cascades to chunks)
            db.delete(doc)
            db.commit()

            logger.info(f"Deleted document {document_id} with {len(chunk_ids)} chunks")

            # Invalidate BM25 so deleted document is not scored on next query
            _invalidate_retriever()

            return {"document_id": document_id, "deleted_chunks": len(chunk_ids), "status": "deleted"}

        except Exception as e:
            db.rollback()
            logger.error(f"Delete document failed: {e}")
            raise
        finally:
            db.close()

    def delete_document_pages(
        self, document_id: str, page_numbers: List[int]
    ) -> Dict[str, Any]:
        """Delete specific pages from a document."""
        chunk_ids = self._get_chunk_ids_for_pages(document_id, page_numbers)

        if chunk_ids:
            self.vector_store.delete_documents(chunk_ids)

        db = get_db_session()
        try:
            db.query(Chunk).filter(
                Chunk.document_id == document_id,
                Chunk.page_number.in_(page_numbers)
            ).delete(synchronize_session=False)
            db.commit()
        finally:
            db.close()

        logger.info(f"Deleted {len(page_numbers)} pages ({len(chunk_ids)} chunks) from {document_id}")

        # Invalidate BM25 so deleted pages are not scored on next query
        _invalidate_retriever()

        return {
            "document_id": document_id,
            "deleted_pages": page_numbers,
            "deleted_chunks": len(chunk_ids),
        }

    def _get_chunk_ids_for_pages(self, document_id: str, page_numbers: List[int]) -> List[str]:
        db = get_db_session()
        try:
            chunks = db.query(Chunk).filter(
                Chunk.document_id == document_id,
                Chunk.page_number.in_(page_numbers)
            ).all()
            return [c.chunk_id for c in chunks]
        finally:
            db.close()

    def _log_audit(self, action: str, entity_type: str, entity_id: str, details: Dict):
        db = get_db_session()
        try:
            log = AuditLog(
                action=action,
                entity_type=entity_type,
                entity_id=entity_id,
                details=details,
            )
            db.add(log)
            db.commit()
        except Exception as e:
            logger.warning(f"Audit log failed: {e}")
        finally:
            db.close()


# Singleton
ingestion_pipeline = IngestionPipeline()
