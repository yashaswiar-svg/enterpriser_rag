"""
FlashRank reranker: reranks top-K vector results to top-N for LLM.
Pipeline: Vector Top-20 → FlashRank → Top-5 → LLM
"""
from typing import List, Dict, Any, Optional

from app.config.settings import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)


class FlashRankReranker:
    """
    Reranks retrieved chunks using FlashRank cross-encoder.
    Reduces vector Top-20 to Top-5 for LLM context.
    """

    def __init__(self, top_n: int = None):
        self.top_n = top_n or settings.RERANK_TOP_N
        self._ranker = None
        self._init_ranker()

    def _init_ranker(self):
        try:
            from flashrank import Ranker, RerankRequest
            self._ranker = Ranker(model_name="ms-marco-MiniLM-L-12-v2", cache_dir="/tmp/flashrank")
            self._RerankRequest = RerankRequest
            logger.info("FlashRank ranker initialized")
        except Exception as e:
            logger.warning(f"FlashRank unavailable, using score-based fallback: {e}")
            self._ranker = None

    def rerank(
        self,
        query: str,
        chunks: List[Dict[str, Any]],
        top_n: int = None,
    ) -> List[Dict[str, Any]]:
        """
        Rerank chunks by relevance to query.
        Returns top_n most relevant chunks.
        """
        top_n = top_n or self.top_n
        if not chunks:
            return []

        if len(chunks) <= top_n:
            return chunks

        if self._ranker is not None:
            return self._flashrank_rerank(query, chunks, top_n)
        else:
            return self._score_based_rerank(query, chunks, top_n)

    def _flashrank_rerank(
        self, query: str, chunks: List[Dict[str, Any]], top_n: int
    ) -> List[Dict[str, Any]]:
        """Use FlashRank cross-encoder for reranking."""
        try:
            passages = [
                {"id": i, "text": c.get("content", ""), "meta": c.get("metadata", {})}
                for i, c in enumerate(chunks)
            ]
            request = self._RerankRequest(query=query, passages=passages)
            results = self._ranker.rerank(request)

            reranked = []
            for result in results[:top_n]:
                idx = result["id"] if isinstance(result, dict) else result.id
                score = result["score"] if isinstance(result, dict) else result.score
                original_chunk = chunks[idx].copy()
                original_chunk["rerank_score"] = score
                reranked.append(original_chunk)

            logger.debug(f"FlashRank: reranked {len(chunks)} → {len(reranked)} chunks")
            return reranked

        except Exception as e:
            logger.error(f"FlashRank reranking failed: {e}")
            return self._score_based_rerank(query, chunks, top_n)

    def _score_based_rerank(
        self, query: str, chunks: List[Dict[str, Any]], top_n: int
    ) -> List[Dict[str, Any]]:
        """Fallback: sort by existing relevance score."""
        def get_score(chunk):
            return max(
                chunk.get("score", 0),
                chunk.get("hybrid_score", 0),
                chunk.get("rerank_score", 0),
            )

        sorted_chunks = sorted(chunks, key=get_score, reverse=True)
        return sorted_chunks[:top_n]

    def rerank_with_scores(
        self, query: str, chunks: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Rerank and attach confidence score to each chunk."""
        reranked = self.rerank(query, chunks)
        max_score = max((c.get("rerank_score", c.get("score", 1)) for c in reranked), default=1)

        for chunk in reranked:
            raw = chunk.get("rerank_score", chunk.get("score", 0.5))
            chunk["confidence"] = min(1.0, raw / max_score if max_score > 0 else 0.5)

        return reranked


# Singleton
reranker = FlashRankReranker()
