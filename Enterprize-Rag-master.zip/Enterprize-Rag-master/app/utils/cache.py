"""
In-memory caching for embeddings and chunks.
"""
import time
import hashlib
import json
from typing import Any, Optional, Dict, List
from collections import OrderedDict
import threading

from app.utils.logger import get_logger

logger = get_logger(__name__)


class LRUCache:
    """Thread-safe LRU cache with TTL support."""

    def __init__(self, max_size: int = 1000, ttl: int = 3600):
        self.max_size = max_size
        self.ttl = ttl
        self._cache: OrderedDict = OrderedDict()
        self._timestamps: Dict[str, float] = {}
        self._lock = threading.RLock()
        self._hits = 0
        self._misses = 0

    def _is_expired(self, key: str) -> bool:
        if key not in self._timestamps:
            return True
        return (time.time() - self._timestamps[key]) > self.ttl

    def get(self, key: str) -> Optional[Any]:
        with self._lock:
            if key not in self._cache or self._is_expired(key):
                if key in self._cache:
                    del self._cache[key]
                    del self._timestamps[key]
                self._misses += 1
                return None
            self._cache.move_to_end(key)
            self._hits += 1
            return self._cache[key]

    def set(self, key: str, value: Any):
        with self._lock:
            if key in self._cache:
                self._cache.move_to_end(key)
            else:
                if len(self._cache) >= self.max_size:
                    oldest_key = next(iter(self._cache))
                    del self._cache[oldest_key]
                    del self._timestamps[oldest_key]
            self._cache[key] = value
            self._timestamps[key] = time.time()

    def delete(self, key: str) -> bool:
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                del self._timestamps[key]
                return True
            return False

    def clear(self):
        with self._lock:
            self._cache.clear()
            self._timestamps.clear()

    def stats(self) -> Dict:
        with self._lock:
            total = self._hits + self._misses
            return {
                "size": len(self._cache),
                "max_size": self.max_size,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": self._hits / total if total > 0 else 0.0,
            }


class EmbeddingCache(LRUCache):
    """Cache specifically for text embeddings."""

    def __init__(self):
        super().__init__(max_size=5000, ttl=86400)  # 24h TTL

    def get_embedding_key(self, text: str, model: str) -> str:
        content = f"{model}:{text}"
        return hashlib.md5(content.encode()).hexdigest()

    def get_embedding(self, text: str, model: str) -> Optional[List[float]]:
        key = self.get_embedding_key(text, model)
        return self.get(key)

    def set_embedding(self, text: str, model: str, embedding: List[float]):
        key = self.get_embedding_key(text, model)
        self.set(key, embedding)


class ChunkCache(LRUCache):
    """Cache for retrieved chunks."""

    def __init__(self):
        super().__init__(max_size=2000, ttl=3600)  # 1h TTL

    def get_query_key(self, query: str, top_k: int) -> str:
        content = f"{query}:{top_k}"
        return hashlib.md5(content.encode()).hexdigest()

    def get_chunks(self, query: str, top_k: int) -> Optional[List]:
        key = self.get_query_key(query, top_k)
        return self.get(key)

    def set_chunks(self, query: str, top_k: int, chunks: List):
        key = self.get_query_key(query, top_k)
        self.set(key, chunks)


# Global cache instances
embedding_cache = EmbeddingCache()
chunk_cache = ChunkCache()
general_cache = LRUCache(max_size=500, ttl=3600)
