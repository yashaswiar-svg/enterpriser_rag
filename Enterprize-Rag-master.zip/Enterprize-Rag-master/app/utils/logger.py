"""
Centralized logging using Loguru.
"""
import sys
import os
from pathlib import Path
from loguru import logger

from app.config.settings import settings


def setup_logger():
    """Configure Loguru logger with file and console handlers."""
    # Remove default handler
    logger.remove()

    # Console handler
    logger.add(
        sys.stdout,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
        level="DEBUG" if settings.DEBUG else "INFO",
        colorize=True,
    )

    # General log file
    os.makedirs(settings.LOGS_DIR, exist_ok=True)
    logger.add(
        os.path.join(settings.LOGS_DIR, "app_{time:YYYY-MM-DD}.log"),
        rotation="1 day",
        retention="30 days",
        level="DEBUG",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
    )

    # Error log file
    logger.add(
        os.path.join(settings.LOGS_DIR, "error_{time:YYYY-MM-DD}.log"),
        rotation="1 day",
        retention="30 days",
        level="ERROR",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
    )

    # Security log file
    logger.add(
        os.path.join(settings.LOGS_DIR, "security_{time:YYYY-MM-DD}.log"),
        rotation="1 day",
        retention="90 days",
        level="WARNING",
        filter=lambda record: "security" in record["extra"],
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | SECURITY | {name}:{function}:{line} - {message}",
    )

    return logger


# Initialize logger
app_logger = setup_logger()


def get_logger(name: str = None):
    """Get a contextualized logger."""
    if name:
        return logger.bind(module=name)
    return logger


def log_security_event(event_type: str, details: str, severity: str = "WARNING"):
    """Log security events to security log."""
    logger.bind(security=True).warning(
        f"[SECURITY EVENT] type={event_type} | severity={severity} | details={details}"
    )
