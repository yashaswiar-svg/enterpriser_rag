"""
Database models and session management using SQLAlchemy.
"""
from datetime import datetime
from typing import Optional
from sqlalchemy import (
    create_engine, Column, String, Integer, Float, DateTime,
    Text, Boolean, JSON, ForeignKey, Index
)
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, Session
from sqlalchemy.pool import StaticPool
import uuid

from app.config.settings import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)

Base = declarative_base()


def generate_uuid():
    return str(uuid.uuid4())


class Document(Base):
    __tablename__ = "documents"

    id = Column(String, primary_key=True, default=generate_uuid)
    document_id = Column(String, unique=True, nullable=False, index=True)
    document_name = Column(String, nullable=False)
    file_path = Column(String, nullable=True)
    file_size = Column(Integer, nullable=True)
    total_pages = Column(Integer, default=0)
    total_chunks = Column(Integer, default=0)
    status = Column(String, default="pending")  # pending, processing, indexed, failed
    error_message = Column(Text, nullable=True)
    doc_metadata = Column(JSON, default={})
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    chunks = relationship("Chunk", back_populates="document", cascade="all, delete-orphan")
    __table_args__ = (Index("idx_document_status", "status"),)


class Chunk(Base):
    __tablename__ = "chunks"

    id = Column(String, primary_key=True, default=generate_uuid)
    chunk_id = Column(String, unique=True, nullable=False, index=True)
    document_id = Column(String, ForeignKey("documents.document_id"), nullable=False)
    document_name = Column(String, nullable=False)
    page_number = Column(Integer, nullable=False)
    chunk_index = Column(Integer, nullable=False)
    content = Column(Text, nullable=False)
    content_hash = Column(String, nullable=True)
    token_count = Column(Integer, default=0)
    embedding_model = Column(String, nullable=True)
    is_indexed = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    document = relationship("Document", back_populates="chunks")
    __table_args__ = (
        Index("idx_chunk_document", "document_id"),
        Index("idx_chunk_page", "document_id", "page_number"),
    )


class Report(Base):
    __tablename__ = "reports"

    id = Column(String, primary_key=True, default=generate_uuid)
    report_id = Column(String, unique=True, nullable=False, index=True)
    query = Column(Text, nullable=False)
    title = Column(String, nullable=True)
    status = Column(String, default="generating")  # generating, completed, failed
    pdf_path = Column(String, nullable=True)
    sections = Column(JSON, default={})
    citations = Column(JSON, default=[])
    confidence_score = Column(Float, default=0.0)
    llm_provider = Column(String, nullable=True)
    processing_time = Column(Float, nullable=True)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(String, primary_key=True, default=generate_uuid)
    action = Column(String, nullable=False)
    entity_type = Column(String, nullable=True)
    entity_id = Column(String, nullable=True)
    user_id = Column(String, nullable=True)
    ip_address = Column(String, nullable=True)
    details = Column(JSON, default={})
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (Index("idx_audit_action", "action"), Index("idx_audit_entity", "entity_type", "entity_id"))


class SecurityEvent(Base):
    __tablename__ = "security_events"

    id = Column(String, primary_key=True, default=generate_uuid)
    event_type = Column(String, nullable=False)
    severity = Column(String, default="WARNING")
    source_ip = Column(String, nullable=True)
    details = Column(JSON, default={})
    raw_input = Column(Text, nullable=True)
    resolved = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (Index("idx_security_type", "event_type"), Index("idx_security_severity", "severity"))


class FeedbackEntry(Base):
    __tablename__ = "feedback"

    id = Column(String, primary_key=True, default=generate_uuid)
    report_id = Column(String, ForeignKey("reports.report_id"), nullable=True)
    query = Column(Text, nullable=True)
    rating = Column(Integer, nullable=True)  # 1-5
    comment = Column(Text, nullable=True)
    helpful = Column(Boolean, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


# Database engine setup
def create_db_engine():
    if "sqlite" in settings.DATABASE_URL:
        engine = create_engine(
            settings.DATABASE_URL,
            connect_args={"check_same_thread": False},
            poolclass=StaticPool,
        )
    else:
        engine = create_engine(
            settings.DATABASE_URL,
            pool_size=10,
            max_overflow=20,
            pool_timeout=30,
        )
    return engine


engine = create_db_engine()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db():
    """Initialize database tables."""
    Base.metadata.create_all(bind=engine)
    logger.info("Database initialized successfully")


def get_db() -> Session:
    """Dependency to get database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_db_session() -> Session:
    """Get a direct database session."""
    return SessionLocal()
