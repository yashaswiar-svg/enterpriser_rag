"""
Google Gemini embedding provider.
"""
from typing import List
import google.generativeai as genai

from app.embeddings.base import BaseEmbedding
from app.config.settings import settings
from app.utils.logger import get_logger
from app.utils.cache import embedding_cache

logger = get_logger(__name__)


class GeminiEmbeddings(BaseEmbedding):
    """Google Gemini text embeddings."""

    def __init__(self):
        if not settings.GOOGLE_API_KEY:
            raise ValueError("GOOGLE_API_KEY not configured")
        genai.configure(api_key=settings.GOOGLE_API_KEY)
        self._model = settings.GEMINI_EMBEDDING_MODEL
        # Detect actual dimension by embedding a test string, so the class
        # works correctly regardless of which Gemini embedding model is used.
        test_result = genai.embed_content(
            model=self._model,
            content="dimension probe",
            task_type="retrieval_query",
        )
        self._dimension = len(test_result["embedding"])
        logger.info(f"GeminiEmbeddings initialized: model={self._model}, dim={self._dimension}")

    @property
    def dimension(self) -> int:
        return self._dimension

    @property
    def model_name(self) -> str:
        return self._model

    def embed_query(self, text: str) -> List[float]:
        """Embed a single query with caching."""
        cached = embedding_cache.get_embedding(text, self._model)
        if cached is not None:
            return cached

        try:
            result = genai.embed_content(
                model=self._model,
                content=text,
                task_type="retrieval_query",
            )
            embedding = result["embedding"]
            embedding_cache.set_embedding(text, self._model, embedding)
            return embedding
        except Exception as e:
            logger.error(f"Gemini embed_query failed: {e}")
            raise

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embed documents in batches with caching."""
        results = []
        uncached_texts = []
        uncached_indices = []

        for i, text in enumerate(texts):
            cached = embedding_cache.get_embedding(text, self._model)
            if cached is not None:
                results.append((i, cached))
            else:
                uncached_texts.append(text)
                uncached_indices.append(i)

        # Batch embed uncached texts
        if uncached_texts:
            batch_size = settings.EMBEDDING_BATCH_SIZE
            for batch_start in range(0, len(uncached_texts), batch_size):
                batch = uncached_texts[batch_start: batch_start + batch_size]
                try:
                    embeddings = []
                    for text in batch:
                        result = genai.embed_content(
                            model=self._model,
                            content=text,
                            task_type="retrieval_document",
                        )
                        embeddings.append(result["embedding"])

                    for j, (text, emb) in enumerate(zip(batch, embeddings)):
                        idx = uncached_indices[batch_start + j]
                        results.append((idx, emb))
                        embedding_cache.set_embedding(text, self._model, emb)

                except Exception as e:
                    logger.error(f"Gemini embed_documents batch failed: {e}")
                    raise

        results.sort(key=lambda x: x[0])
        return [emb for _, emb in results]
