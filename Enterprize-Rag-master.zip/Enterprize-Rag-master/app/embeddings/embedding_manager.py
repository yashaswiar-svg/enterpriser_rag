"""
Embedding manager with automatic fallback.
"""
from typing import List, Optional

from app.embeddings.base import BaseEmbedding
from app.config.settings import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)


class EmbeddingManager:
    """Manages embedding providers with automatic fallback."""

    _instance: Optional["EmbeddingManager"] = None
    _embedding_model: Optional[BaseEmbedding] = None

    @classmethod
    def get_instance(cls) -> "EmbeddingManager":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._model = self._initialize_embedding()

    def _initialize_embedding(self) -> BaseEmbedding:
        """Initialize embedding with fallback chain."""
        if settings.PRIMARY_EMBEDDING == "gemini" and settings.GOOGLE_API_KEY:
            try:
                from app.embeddings.gemini_embeddings import GeminiEmbeddings
                model = GeminiEmbeddings()
                # Test the key with a quick embed to catch invalid key early
                model.embed_query("test")
                logger.info("Using Gemini embeddings")
                return model
            except Exception as e:
                logger.warning(f"Gemini embeddings failed, falling back to SentenceTransformers: {e}")

        # Fallback to SentenceTransformers
        try:
            from app.embeddings.sentence_transformer_embeddings import SentenceTransformerEmbeddings
            model = SentenceTransformerEmbeddings()
            logger.info("Using SentenceTransformer embeddings (fallback)")
            return model
        except Exception as e:
            logger.error(f"All embedding providers failed: {e}")
            raise RuntimeError("No embedding provider available")

    @property
    def model(self) -> BaseEmbedding:
        return self._model

    def embed_query(self, text: str) -> List[float]:
        return self._model.embed_query(text)

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        return self._model.embed_documents(texts)

    async def aembed_query(self, text: str) -> List[float]:
        return await self._model.aembed_query(text)

    async def aembed_documents(self, texts: List[str]) -> List[List[float]]:
        return await self._model.aembed_documents(texts)

    @property
    def dimension(self) -> int:
        return self._model.dimension

    @property
    def model_name(self) -> str:
        return self._model.model_name


# Global instance
embedding_manager = EmbeddingManager.get_instance()
