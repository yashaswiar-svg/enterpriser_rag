"""
Sentence Transformers fallback embedding provider.
"""
from typing import List

from app.embeddings.base import BaseEmbedding
from app.config.settings import settings
from app.utils.logger import get_logger
from app.utils.cache import embedding_cache

logger = get_logger(__name__)


class SentenceTransformerEmbeddings(BaseEmbedding):
    """Sentence Transformer embeddings as fallback."""

    def __init__(self, model_name: str = None):
        from sentence_transformers import SentenceTransformer
        self._model_name = model_name or settings.SENTENCE_TRANSFORMER_MODEL
        self._model = SentenceTransformer(self._model_name)
        self._dimension = self._model.get_sentence_embedding_dimension()
        logger.info(f"SentenceTransformerEmbeddings initialized: {self._model_name}, dim={self._dimension}")

    @property
    def dimension(self) -> int:
        return self._dimension

    @property
    def model_name(self) -> str:
        return self._model_name

    def embed_query(self, text: str) -> List[float]:
        cached = embedding_cache.get_embedding(text, self._model_name)
        if cached is not None:
            return cached

        try:
            embedding = self._model.encode(text, convert_to_numpy=True).tolist()
            embedding_cache.set_embedding(text, self._model_name, embedding)
            return embedding
        except Exception as e:
            logger.error(f"SentenceTransformer embed_query failed: {e}")
            raise

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        results = []
        uncached_texts = []
        uncached_indices = []

        for i, text in enumerate(texts):
            cached = embedding_cache.get_embedding(text, self._model_name)
            if cached is not None:
                results.append((i, cached))
            else:
                uncached_texts.append(text)
                uncached_indices.append(i)

        if uncached_texts:
            batch_size = settings.EMBEDDING_BATCH_SIZE
            for batch_start in range(0, len(uncached_texts), batch_size):
                batch = uncached_texts[batch_start: batch_start + batch_size]
                try:
                    embeddings = self._model.encode(
                        batch, convert_to_numpy=True, batch_size=32
                    ).tolist()
                    for j, (text, emb) in enumerate(zip(batch, embeddings)):
                        idx = uncached_indices[batch_start + j]
                        results.append((idx, emb))
                        embedding_cache.set_embedding(text, self._model_name, emb)
                except Exception as e:
                    logger.error(f"SentenceTransformer batch embed failed: {e}")
                    raise

        results.sort(key=lambda x: x[0])
        return [emb for _, emb in results]
