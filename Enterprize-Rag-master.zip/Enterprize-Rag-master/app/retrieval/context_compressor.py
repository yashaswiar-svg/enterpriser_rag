"""
Context compression: removes irrelevant content from retrieved chunks
before sending to LLM to minimize token usage.
"""
from typing import List, Dict, Any
import re

from app.config.settings import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)


class ContextCompressor:
    """
    Compresses context by filtering, deduplicating, and trimming chunks
    to fit within the LLM's context window.
    """

    def __init__(self, max_tokens: int = None):
        self.max_tokens = max_tokens or settings.MAX_CONTEXT_TOKENS

    def _estimate_tokens(self, text: str) -> int:
        """Rough token estimate: ~4 chars per token."""
        return max(1, len(text) // 4)

    def _remove_duplicates(self, chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Remove near-duplicate chunks based on content similarity."""
        seen_hashes = set()
        unique_chunks = []
        for chunk in chunks:
            content = chunk.get("content", "")
            # Simple dedup: first 100 chars + last 50 chars as fingerprint
            fingerprint = content[:100] + content[-50:] if len(content) > 150 else content
            if fingerprint not in seen_hashes:
                seen_hashes.add(fingerprint)
                unique_chunks.append(chunk)
        return unique_chunks

    def _clean_text(self, text: str) -> str:
        """Clean up extracted text."""
        # Remove excessive whitespace
        text = re.sub(r'\n{3,}', '\n\n', text)
        text = re.sub(r' {2,}', ' ', text)
        # Remove page number artifacts
        text = re.sub(r'^\s*\d+\s*$', '', text, flags=re.MULTILINE)
        return text.strip()

    def compress(
        self,
        chunks: List[Dict[str, Any]],
        query: str = None,
    ) -> List[Dict[str, Any]]:
        """
        Compress a list of chunks:
        1. Remove duplicates
        2. Clean text
        3. Truncate to token budget
        """
        if not chunks:
            return []

        # Remove duplicates
        chunks = self._remove_duplicates(chunks)

        # Clean content
        for chunk in chunks:
            if "content" in chunk:
                chunk["content"] = self._clean_text(chunk["content"])

        # Remove empty chunks
        chunks = [c for c in chunks if c.get("content", "").strip()]

        # Sort by score (highest relevance first)
        chunks = sorted(chunks, key=lambda x: x.get("score", x.get("hybrid_score", 0)), reverse=True)

        # Trim to token budget
        compressed = []
        total_tokens = 0
        for chunk in chunks:
            chunk_tokens = self._estimate_tokens(chunk.get("content", ""))
            if total_tokens + chunk_tokens > self.max_tokens:
                # Try to fit a trimmed version
                remaining = self.max_tokens - total_tokens
                if remaining > 100:
                    max_chars = remaining * 4
                    chunk = chunk.copy()
                    chunk["content"] = chunk["content"][:max_chars] + "..."
                    chunk["truncated"] = True
                    compressed.append(chunk)
                break
            compressed.append(chunk)
            total_tokens += chunk_tokens

        logger.debug(
            f"Context compression: {len(chunks)} → {len(compressed)} chunks, "
            f"~{total_tokens} tokens"
        )
        return compressed

    def format_context(self, chunks: List[Dict[str, Any]]) -> str:
        """Format chunks into a single context string with citations."""
        if not chunks:
            return "No relevant context found."

        parts = []
        for i, chunk in enumerate(chunks, start=1):
            meta = chunk.get("metadata", {})
            doc_name = meta.get("document_name", "Unknown")
            page = meta.get("page_number", "?")
            content = chunk.get("content", "")

            parts.append(
                f"[Source {i}] Document: '{doc_name}', Page: {page}\n{content}"
            )

        return "\n\n---\n\n".join(parts)


# Singleton
context_compressor = ContextCompressor()
