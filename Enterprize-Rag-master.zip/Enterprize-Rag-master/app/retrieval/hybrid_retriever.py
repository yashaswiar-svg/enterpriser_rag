"""
Hybrid retrieval combining BM25 (sparse) + vector (dense) search.
Implements the full retrieve → rerank → compress pipeline.
"""
from typing import List, Dict, Any, Optional
import math

from app.vectorstore.chroma_store import ChromaVectorStore
from app.embeddings.embedding_manager import embedding_manager
from app.config.settings import settings
from app.utils.logger import get_logger
from app.utils.cache import chunk_cache

logger = get_logger(__name__)


class BM25Retriever:
    """Simple BM25 implementation over stored chunks."""

    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1 = k1
        self.b = b
        self._corpus: List[Dict] = []
        self._inverted_index: Dict[str, List[int]] = {}
        self._df: Dict[str, int] = {}
        self._avgdl: float = 0.0
        self._built = False

    def build_index(self, documents: List[Dict[str, Any]]):
        """Build BM25 index from documents list (each has 'content', 'id', 'metadata')."""
        self._corpus = documents
        self._inverted_index = {}
        self._df = {}
        total_len = 0

        for i, doc in enumerate(documents):
            tokens = doc["content"].lower().split()
            total_len += len(tokens)
            seen = set()
            for token in tokens:
                if token not in seen:
                    self._df[token] = self._df.get(token, 0) + 1
                    seen.add(token)
                if token not in self._inverted_index:
                    self._inverted_index[token] = []
                self._inverted_index[token].append(i)

        self._avgdl = total_len / max(len(documents), 1)
        self._built = True
        logger.debug(f"BM25 index built: {len(documents)} docs, {len(self._df)} terms")

    def search(self, query: str, top_k: int = 20) -> List[Dict[str, Any]]:
        """BM25 search returning scored documents."""
        if not self._built or not self._corpus:
            return []

        query_tokens = query.lower().split()
        N = len(self._corpus)
        scores: Dict[int, float] = {}

        for token in query_tokens:
            if token not in self._inverted_index:
                continue
            df = self._df.get(token, 0)
            idf = math.log((N - df + 0.5) / (df + 0.5) + 1)

            for doc_idx in self._inverted_index[token]:
                doc = self._corpus[doc_idx]
                dl = len(doc["content"].split())
                tf = doc["content"].lower().split().count(token)
                term_score = idf * (tf * (self.k1 + 1)) / (
                    tf + self.k1 * (1 - self.b + self.b * dl / self._avgdl)
                )
                scores[doc_idx] = scores.get(doc_idx, 0) + term_score

        sorted_docs = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_k]
        results = []
        for idx, score in sorted_docs:
            doc = self._corpus[idx].copy()
            doc["bm25_score"] = score
            results.append(doc)

        return results


class HybridRetriever:
    """
    Combines BM25 + vector search results using Reciprocal Rank Fusion (RRF).
    """

    def __init__(self):
        self.vector_store = ChromaVectorStore()
        self.bm25 = BM25Retriever()
        self._bm25_corpus: List[Dict] = []
        logger.info("HybridRetriever initialized")

    def invalidate_bm25(self):
        """Reset the BM25 index so it is rebuilt on the next query.
        Must be called after any document ingestion or deletion."""
        self.bm25._built = False
        self._bm25_corpus = []
        chunk_cache.clear()
        logger.info("BM25 index invalidated and chunk cache cleared")

    def _load_bm25_corpus(self):
        """Load all chunks from ChromaDB to build the global BM25 index."""
        try:
            result = self.vector_store.collection.get(
                include=["documents", "metadatas"],
                limit=100000,
            )
            corpus = []
            if result and result.get("ids"):
                for i, doc_id in enumerate(result["ids"]):
                    corpus.append({
                        "id": doc_id,
                        "content": result["documents"][i],
                        "metadata": result["metadatas"][i],
                    })
            self.bm25.build_index(corpus)
            self._bm25_corpus = corpus
            logger.info(f"BM25 corpus loaded: {len(corpus)} chunks")
        except Exception as e:
            logger.error(f"BM25 corpus load failed: {e}")

    def _load_scoped_corpus(self, document_ids: List[str]) -> List[Dict]:
        """Load chunks from ChromaDB for only the specified document_ids.
        Used to build a scoped BM25 index that only scores relevant documents."""
        try:
            # ChromaDB $in filter to fetch only the target documents
            result = self.vector_store.collection.get(
                include=["documents", "metadatas"],
                where={"document_id": {"$in": document_ids}},
                limit=100000,
            )
            corpus = []
            if result and result.get("ids"):
                for i, doc_id in enumerate(result["ids"]):
                    corpus.append({
                        "id": doc_id,
                        "content": result["documents"][i],
                        "metadata": result["metadatas"][i],
                    })
            logger.info(f"Scoped BM25 corpus loaded: {len(corpus)} chunks for {len(document_ids)} document(s)")
            return corpus
        except Exception as e:
            logger.error(f"Scoped BM25 corpus load failed: {e}")
            return []

    def _reciprocal_rank_fusion(
        self,
        vector_results: List[Dict],
        bm25_results: List[Dict],
        k: int = 60,
    ) -> List[Dict]:
        """Merge two ranked lists using RRF."""
        rrf_scores: Dict[str, float] = {}
        doc_map: Dict[str, Dict] = {}

        for rank, doc in enumerate(vector_results):
            doc_id = doc["id"]
            rrf_scores[doc_id] = rrf_scores.get(doc_id, 0) + 1 / (k + rank + 1)
            doc_map[doc_id] = doc

        for rank, doc in enumerate(bm25_results):
            doc_id = doc["id"]
            rrf_scores[doc_id] = rrf_scores.get(doc_id, 0) + 1 / (k + rank + 1)
            if doc_id not in doc_map:
                doc_map[doc_id] = doc

        sorted_ids = sorted(rrf_scores.items(), key=lambda x: x[1], reverse=True)
        merged = []
        for doc_id, rrf_score in sorted_ids:
            doc = doc_map[doc_id].copy()
            doc["hybrid_score"] = rrf_score
            merged.append(doc)

        return merged

    def retrieve(
        self,
        query: str,
        top_k: int = None,
        document_ids: Optional[List[str]] = None,
        use_hybrid: bool = True,
    ) -> List[Dict[str, Any]]:
        """
        Full hybrid retrieval. Returns top_k chunks.
        When document_ids is provided, both vector search AND BM25 are scoped
        to only those documents — BM25 builds a temporary index from the
        filtered corpus instead of post-filtering the global one.
        """
        top_k = top_k or settings.VECTOR_SEARCH_TOP_K

        # Check cache
        cache_key_extra = str(sorted(document_ids or []))
        cache_key = f"{query}:{top_k}:{cache_key_extra}:{use_hybrid}"
        cached = chunk_cache.get(cache_key)
        if cached:
            logger.debug("Returning cached retrieval results")
            return cached

        # Vector search (ChromaDB where-filter handles scoping)
        query_embedding = embedding_manager.embed_query(query)
        where_filter = None
        if document_ids:
            where_filter = {"document_id": {"$in": document_ids}}

        vector_results = self.vector_store.query(
            query_embedding=query_embedding,
            n_results=top_k,
            where=where_filter,
        )

        if not use_hybrid:
            chunk_cache.set(cache_key, vector_results)
            return vector_results

        # BM25 search — scoped or global depending on document_ids
        if document_ids:
            # Build a scoped BM25 index from only the target documents
            # so that BM25 scoring is not polluted by unrelated documents
            scoped_corpus = self._load_scoped_corpus(document_ids)
            scoped_bm25 = BM25Retriever()
            scoped_bm25.build_index(scoped_corpus)
            bm25_results = scoped_bm25.search(query, top_k=top_k)
        else:
            # Global BM25 — rebuild lazily if invalidated
            if not self.bm25._built:
                self._load_bm25_corpus()
            bm25_results = self.bm25.search(query, top_k=top_k)

        # Fuse results
        merged = self._reciprocal_rank_fusion(vector_results, bm25_results)[:top_k]

        chunk_cache.set(cache_key, merged)
        return merged


# Singleton
hybrid_retriever = HybridRetriever()
