"""
Application settings and configuration management.
"""
import os
from pathlib import Path
from typing import Optional
from pydantic_settings import BaseSettings
from pydantic import Field


BASE_DIR = Path(__file__).resolve().parent.parent.parent


class Settings(BaseSettings):
    # Application
    APP_NAME: str = "Enterprise Research Assistant RAG"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    ENVIRONMENT: str = "production"

    # API Keys
    GOOGLE_API_KEY: Optional[str] = Field(default=None)
    OPENAI_API_KEY: Optional[str] = Field(default=None)
    LANGCHAIN_API_KEY: Optional[str] = Field(default=None)
    LANGCHAIN_TRACING_V2: bool = Field(default=False)
    LANGCHAIN_PROJECT: str = Field(default="enterprise-rag")

    # LLM Settings
    PRIMARY_LLM: str = "gemini"
    GEMINI_MODEL: str = "gemini-2.5-flash"
    OPENAI_MODEL: str = "gpt-4o"
    LLM_TEMPERATURE: float = 0.1
    LLM_MAX_TOKENS: int = 8192
    LLM_TIMEOUT: int = 60

    # Embedding Settings
    PRIMARY_EMBEDDING: str = "gemini"
    GEMINI_EMBEDDING_MODEL: str = "models/gemini-embedding-001"
    SENTENCE_TRANSFORMER_MODEL: str = "all-MiniLM-L6-v2"
    EMBEDDING_BATCH_SIZE: int = 100
    EMBEDDING_DIM: int = 3072  # gemini-embedding-001 output dimension

    # Vector Store
    CHROMA_PERSIST_DIR: str = str(BASE_DIR / "chroma_db")
    CHROMA_COLLECTION_NAME: str = "enterprise_rag"
    FAISS_INDEX_PATH: str = str(BASE_DIR / "chroma_db" / "faiss_index")

    # Document Processing
    CHUNK_SIZE: int = 1000
    CHUNK_OVERLAP: int = 200
    MAX_CHUNKS_PER_DOC: int = 10000
    BATCH_SIZE: int = 50
    MAX_FILE_SIZE_MB: int = 100

    # Retrieval
    VECTOR_SEARCH_TOP_K: int = 20
    RERANK_TOP_N: int = 5
    HYBRID_SEARCH_ALPHA: float = 0.5  # weight for vector vs BM25

    # Paths
    DATA_DIR: str = str(BASE_DIR / "data")
    DOCUMENTS_DIR: str = str(BASE_DIR / "data" / "documents")
    METADATA_DIR: str = str(BASE_DIR / "data" / "metadata")
    REPORTS_DIR: str = str(BASE_DIR / "reports")
    LOGS_DIR: str = str(BASE_DIR / "logs")

    # Database
    DATABASE_URL: str = f"sqlite:///{BASE_DIR}/enterprise_rag.db"

    # Security
    SECRET_KEY: str = "enterprise-rag-secret-key-change-in-production"
    API_KEY_HEADER: str = "X-API-Key"
    ALLOWED_ORIGINS: list = ["*"]

    # Performance
    MAX_CONTEXT_TOKENS: int = 100000
    CACHE_TTL: int = 3600
    MAX_CONCURRENT_REQUESTS: int = 10
    WORKER_THREADS: int = 4

    # Report Generation
    REPORT_TEMPLATE_DIR: str = str(BASE_DIR / "app" / "reports" / "templates")
    MAX_REPORT_SECTIONS: int = 10

    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "case_sensitive": True,
        "extra": "ignore",
    }


settings = Settings()

# Ensure directories exist
for dir_path in [
    settings.DATA_DIR,
    settings.DOCUMENTS_DIR,
    settings.METADATA_DIR,
    settings.REPORTS_DIR,
    settings.LOGS_DIR,
    settings.CHROMA_PERSIST_DIR,
]:
    os.makedirs(dir_path, exist_ok=True)
